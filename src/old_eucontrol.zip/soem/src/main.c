#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "ethercat.h"

static void print_usage(const char *exe)
{
    printf("用法:\n");
    printf("  sudo %s --list\n", exe);
    printf("  sudo %s <适配器名> [从站序号=1] [目标位置=10000]\n\n", exe);
}

static void list_adapters(void)
{
    ec_adaptert *adapter = ec_find_adapters();
    if (!adapter)
    {
        printf("未发现可用网卡(适配器)。\n");
        return;
    }
    printf("可用适配器列表:\n");
    while (adapter)
    {
        printf("  name: %s\n", adapter->name);
        if (adapter->desc && strlen(adapter->desc) > 0)
            printf("  desc: %s\n", adapter->desc);
        printf("\n");
        adapter = adapter->next;
    }
}

static int cia402_enable_operation_via_sdo(uint16 slave)
{
    // 设置模式: Profile Position (1)
    uint8 mode = 1; // 1: PP, 3: PV, 8: CSP 等
    if (!ec_SDOwrite(slave, 0x6060, 0, FALSE, sizeof(mode), &mode, EC_TIMEOUTRXM))
    {
        printf("写入模式(6060h)失败\n");
        return 0;
    }
    // 状态机: Shutdown -> Switch On -> Enable Operation
    uint16 cw = 0x0006; // Shutdown
    if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return 0;

    cw = 0x0007; // Switch on
    if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return 0;

    cw = 0x000F; // Enable operation
    if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return 0;

    return 1;
}

static int cia402_move_to_position(uint16 slave, int32_t target_pos)
{
    if (!ec_SDOwrite(slave, 0x607A, 0, FALSE, sizeof(target_pos), &target_pos, EC_TIMEOUTRXM))
    {
        printf("写入目标位置(607Ah)失败\n");
        return 0;
    }
    // 触发新设定点: 控制字bit4置位，然后复位
    uint16 cw = 0x001F; // Enable op + New set-point
    if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return 0;

    cw = 0x000F; // 清除新设定点位
    if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return 0;

    return 1;
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        print_usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "--list") == 0)
    {
        list_adapters();
        return 0;
    }

    const char *ifname = argv[1];
    uint16 slave_index = (argc >= 3) ? (uint16)atoi(argv[2]) : 1;
    int32_t target_pos = (argc >= 4) ? (int32_t)atoi(argv[3]) : 10000;

    printf("适配器: %s, 目标从站: %u, 目标位置: %d\n", ifname, slave_index, target_pos);

    printf("初始化EtherCAT主站...\n");
    if (!ec_init(ifname))
    {
        printf("ec_init失败，检查适配器名或权限(需要sudo)。\n");
        return 1;
    }

    printf("开始配置从站...\n");
    if (ec_config_init(FALSE) <= 0)
    {
        printf("未发现任何从站，请检查网络与拓扑。\n");
        ec_close();
        return 1;
    }

    printf("发现从站数量: %d\n", ec_slavecount);
    if (slave_index == 0 || slave_index > ec_slavecount)
    {
        printf("从站序号无效(1..%d)。\n", ec_slavecount);
        ec_close();
        return 1;
    }

    // 映射PDO与分布式时钟(可选)
    static char IOmap[4096];
    ec_config_map(&IOmap);
    ec_configdc();

    // 切到OP
    ec_statecheck(0, EC_STATE_SAFE_OP, EC_TIMEOUTSTATE);
    ec_slave[0].state = EC_STATE_OPERATIONAL;
    ec_writestate(0);
    if (ec_statecheck(0, EC_STATE_OPERATIONAL, EC_TIMEOUTSTATE) != EC_STATE_OPERATIONAL)
    {
        printf("进入OP状态失败。\n");
        ec_close();
        return 1;
    }
    printf("主站进入OP。\n");

    // 基于SDO的CiA‑402简单演示（更高性能应改为PDO循環发送）
    if (!cia402_enable_operation_via_sdo(slave_index))
    {
        printf("CiA‑402使能失败。\n");
        ec_close();
        return 1;
    }
    printf("从站%u已使能操作(Enable Operation)。\n", slave_index);

    if (!cia402_move_to_position(slave_index, target_pos))
    {
        printf("发送位置命令失败。\n");
        ec_close();
        return 1;
    }
    printf("已发送位置命令: %d\n", target_pos);

    // 简单循环，让总线跑一段时间以便动作完成
    for (int i = 0; i < 200; ++i)
    {
        ec_send_processdata();
        ec_receive_processdata(EC_TIMEOUTRET);
        osal_usleep(10000); // 10ms
    }

    // 读状态字与实际位置（SDO，演示用途）
    uint16 status = 0;
    int size = sizeof(status);
    ec_SDOread(slave_index, 0x6041, 0, FALSE, &size, &status, EC_TIMEOUTRXM);
    printf("状态字(6041h): 0x%04X\n", status);

    int32_t actpos = 0;
    size = sizeof(actpos);
    ec_SDOread(slave_index, 0x6064, 0, FALSE, &size, &actpos, EC_TIMEOUTRXM);
    printf("实际位置(6064h): %d\n", actpos);

    ec_close();
    printf("完成并关闭主站。\n");
    return 0;
}