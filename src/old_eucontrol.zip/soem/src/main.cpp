#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <chrono>
#include <memory>
#include <string>
#include <vector>

extern "C" {
#include "ethercat.h"
}

using namespace std::chrono_literals;

class EtherCATMotorControlNode : public rclcpp::Node
{
public:
    EtherCATMotorControlNode() : Node("ecat_motor_control_node")
    {
        // 声明参数
        this->declare_parameter<std::string>("adapter_name", "");
        this->declare_parameter<int>("slave_index", 1);
        this->declare_parameter<int>("target_position", 10000);
        this->declare_parameter<bool>("list_adapters", false);
        this->declare_parameter<double>("control_frequency", 100.0);
        
        // 获取参数
        adapter_name_ = this->get_parameter("adapter_name").as_string();
        slave_index_ = this->get_parameter("slave_index").as_int();
        target_position_ = this->get_parameter("target_position").as_int();
        bool list_adapters = this->get_parameter("list_adapters").as_bool();
        double control_freq = this->get_parameter("control_frequency").as_double();
        
        // 如果需要列出适配器
        if (list_adapters) {
            list_available_adapters();
            return;
        }
        
        // 检查适配器名称
        if (adapter_name_.empty()) {
            RCLCPP_ERROR(this->get_logger(), "适配器名称未指定。请设置adapter_name参数。");
            return;
        }
        
        // 创建发布者和订阅者
        status_publisher_ = this->create_publisher<std_msgs::msg::String>("ecat_status", 10);
        joint_state_publisher_ = this->create_publisher<sensor_msgs::msg::JointState>("joint_states", 10);
        
        cmd_vel_subscriber_ = this->create_subscription<geometry_msgs::msg::Twist>(
            "cmd_vel", 10,
            std::bind(&EtherCATMotorControlNode::cmd_vel_callback, this, std::placeholders::_1));
        
        // 初始化EtherCAT
        if (!initialize_ethercat()) {
            RCLCPP_ERROR(this->get_logger(), "EtherCAT初始化失败");
            return;
        }
        
        // 创建控制定时器
        auto period = std::chrono::duration<double>(1.0 / control_freq);
        control_timer_ = this->create_wall_timer(
            std::chrono::duration_cast<std::chrono::nanoseconds>(period),
            std::bind(&EtherCATMotorControlNode::control_loop, this));
        
        // 创建状态发布定时器
        status_timer_ = this->create_wall_timer(
            1s, std::bind(&EtherCATMotorControlNode::publish_status, this));
        
        RCLCPP_INFO(this->get_logger(), "EtherCAT电机控制节点已启动");
        RCLCPP_INFO(this->get_logger(), "适配器: %s, 从站: %d", adapter_name_.c_str(), slave_index_);
    }
    
    ~EtherCATMotorControlNode()
    {
        if (ethercat_initialized_) {
            ec_close();
            RCLCPP_INFO(this->get_logger(), "EtherCAT连接已关闭");
        }
    }

private:
    // 参数
    std::string adapter_name_;
    int slave_index_;
    int target_position_;
    bool ethercat_initialized_ = false;
    
    // ROS2 组件
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr status_publisher_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_state_publisher_;
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_subscriber_;
    rclcpp::TimerBase::SharedPtr control_timer_;
    rclcpp::TimerBase::SharedPtr status_timer_;
    
    // 控制变量
    int32_t current_target_position_ = 0;
    bool new_position_command_ = false;
    
    void list_available_adapters()
    {
        RCLCPP_INFO(this->get_logger(), "扫描可用适配器...");
        ec_adaptert *adapter = ec_find_adapters();
        if (!adapter) {
            RCLCPP_WARN(this->get_logger(), "未发现可用网卡(适配器)");
            return;
        }
        
        RCLCPP_INFO(this->get_logger(), "可用适配器列表:");
        while (adapter) {
            RCLCPP_INFO(this->get_logger(), "  name: %s", adapter->name);
            if (adapter->desc && strlen(adapter->desc) > 0) {
                RCLCPP_INFO(this->get_logger(), "  desc: %s", adapter->desc);
            }
            adapter = adapter->next;
        }
    }
    
    bool initialize_ethercat()
    {
        RCLCPP_INFO(this->get_logger(), "初始化EtherCAT主站...");
        if (!ec_init(adapter_name_.c_str())) {
            RCLCPP_ERROR(this->get_logger(), "ec_init失败，检查适配器名或权限");
            return false;
        }
        
        RCLCPP_INFO(this->get_logger(), "开始配置从站...");
        if (ec_config_init(FALSE) <= 0) {
            RCLCPP_ERROR(this->get_logger(), "未发现任何从站，请检查网络与拓扑");
            ec_close();
            return false;
        }
        
        RCLCPP_INFO(this->get_logger(), "发现从站数量: %d", ec_slavecount);
        if (slave_index_ <= 0 || slave_index_ > ec_slavecount) {
            RCLCPP_ERROR(this->get_logger(), "从站序号无效(1..%d)", ec_slavecount);
            ec_close();
            return false;
        }
        
        // 映射PDO与分布式时钟
        static char IOmap[4096];
        ec_config_map(&IOmap);
        ec_configdc();
        
        // 切到OP
        ec_statecheck(0, EC_STATE_SAFE_OP, EC_TIMEOUTSTATE);
        ec_slave[0].state = EC_STATE_OPERATIONAL;
        ec_writestate(0);
        if (ec_statecheck(0, EC_STATE_OPERATIONAL, EC_TIMEOUTSTATE) != EC_STATE_OPERATIONAL) {
            RCLCPP_ERROR(this->get_logger(), "进入OP状态失败");
            ec_close();
            return false;
        }
        
        RCLCPP_INFO(this->get_logger(), "主站进入OP状态");
        
        // 使能CiA-402操作
        if (!cia402_enable_operation(slave_index_)) {
            RCLCPP_ERROR(this->get_logger(), "CiA-402使能失败");
            ec_close();
            return false;
        }
        
        RCLCPP_INFO(this->get_logger(), "从站%d已使能操作", slave_index_);
        ethercat_initialized_ = true;
        return true;
    }
    
    bool cia402_enable_operation(uint16 slave)
    {
        // 设置模式: Profile Position (1)
        uint8 mode = 1;
        if (!ec_SDOwrite(slave, 0x6060, 0, FALSE, sizeof(mode), &mode, EC_TIMEOUTRXM)) {
            RCLCPP_ERROR(this->get_logger(), "写入模式(6060h)失败");
            return false;
        }
        
        // 状态机: Shutdown -> Switch On -> Enable Operation
        uint16 cw = 0x0006; // Shutdown
        if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return false;
        
        cw = 0x0007; // Switch on
        if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return false;
        
        cw = 0x000F; // Enable operation
        if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return false;
        
        return true;
    }
    
    bool cia402_move_to_position(uint16 slave, int32_t target_pos)
    {
        if (!ec_SDOwrite(slave, 0x607A, 0, FALSE, sizeof(target_pos), &target_pos, EC_TIMEOUTRXM)) {
            RCLCPP_ERROR(this->get_logger(), "写入目标位置(607Ah)失败");
            return false;
        }
        
        // 触发新设定点
        uint16 cw = 0x001F; // Enable op + New set-point
        if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return false;
        
        cw = 0x000F; // 清除新设定点位
        if (!ec_SDOwrite(slave, 0x6040, 0, FALSE, sizeof(cw), &cw, EC_TIMEOUTRXM)) return false;
        
        return true;
    }
    
    void cmd_vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg)
    {
        // 将线速度转换为位置命令（简单示例）
        // 实际应用中需要根据具体的运动学模型进行转换
        int32_t new_position = static_cast<int32_t>(msg->linear.x * 10000);
        
        if (new_position != current_target_position_) {
            current_target_position_ = new_position;
            new_position_command_ = true;
            RCLCPP_INFO(this->get_logger(), "收到新的位置命令: %d", current_target_position_);
        }
    }
    
    void control_loop()
    {
        if (!ethercat_initialized_) return;
        
        // 处理新的位置命令
        if (new_position_command_) {
            if (cia402_move_to_position(slave_index_, current_target_position_)) {
                RCLCPP_INFO(this->get_logger(), "已发送位置命令: %d", current_target_position_);
            }
            new_position_command_ = false;
        }
        
        // 发送和接收过程数据
        ec_send_processdata();
        ec_receive_processdata(EC_TIMEOUTRET);
    }
    
    void publish_status()
    {
        if (!ethercat_initialized_) return;
        
        // 读取状态字
        uint16 status = 0;
        int size = sizeof(status);
        ec_SDOread(slave_index_, 0x6041, 0, FALSE, &size, &status, EC_TIMEOUTRXM);
        
        // 读取实际位置
        int32_t actual_pos = 0;
        size = sizeof(actual_pos);
        ec_SDOread(slave_index_, 0x6064, 0, FALSE, &size, &actual_pos, EC_TIMEOUTRXM);
        
        // 发布状态信息
        auto status_msg = std_msgs::msg::String();
        status_msg.data = "Status: 0x" + std::to_string(status) + ", Position: " + std::to_string(actual_pos);
        status_publisher_->publish(status_msg);
        
        // 发布关节状态
        auto joint_msg = sensor_msgs::msg::JointState();
        joint_msg.header.stamp = this->get_clock()->now();
        joint_msg.name = {"motor_joint"};
        joint_msg.position = {static_cast<double>(actual_pos) / 10000.0}; // 转换为弧度或米
        joint_state_publisher_->publish(joint_msg);
    }
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<EtherCATMotorControlNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}