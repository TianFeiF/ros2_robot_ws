#!/usr/bin/env bash
set -euo pipefail

# Ubuntu 22.04 环境初始化脚本（可选）
# 使用方法：
#   chmod +x scripts/setup_ubuntu.sh
#   sudo ./scripts/setup_ubuntu.sh

apt update
apt install -y git build-essential cmake libcap2-bin

echo "完成：基础依赖已安装。"