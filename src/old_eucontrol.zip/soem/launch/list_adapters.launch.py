#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    """列出可用EtherCAT适配器的简化启动文件"""
    
    list_adapters_node = Node(
        package='soem_ethercat_motor',
        executable='ecat_motor_control_node',
        name='ecat_adapter_lister',
        output='screen',
        parameters=[{
            'list_adapters': True,
        }]
    )
    
    return LaunchDescription([
        list_adapters_node,
    ])