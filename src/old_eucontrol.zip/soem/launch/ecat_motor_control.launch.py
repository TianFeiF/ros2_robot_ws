#!/usr/bin/env python3

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration, TextSubstitution
from launch_ros.actions import Node
from launch.conditions import IfCondition, UnlessCondition


def generate_launch_description():
    # 声明启动参数
    adapter_name_arg = DeclareLaunchArgument(
        'adapter_name',
        default_value='',
        description='EtherCAT网卡适配器名称 (例如: enp3s0, eth0)'
    )
    
    slave_index_arg = DeclareLaunchArgument(
        'slave_index',
        default_value='1',
        description='EtherCAT从站序号'
    )
    
    target_position_arg = DeclareLaunchArgument(
        'target_position',
        default_value='10000',
        description='初始目标位置'
    )
    
    list_adapters_arg = DeclareLaunchArgument(
        'list_adapters',
        default_value='false',
        description='是否列出可用适配器'
    )
    
    control_frequency_arg = DeclareLaunchArgument(
        'control_frequency',
        default_value='100.0',
        description='控制循环频率 (Hz)'
    )
    
    # EtherCAT电机控制节点
    ecat_motor_node = Node(
        package='soem_ethercat_motor',
        executable='ecat_motor_control_node',
        name='ecat_motor_control_node',
        output='screen',
        parameters=[{
            'adapter_name': LaunchConfiguration('adapter_name'),
            'slave_index': LaunchConfiguration('slave_index'),
            'target_position': LaunchConfiguration('target_position'),
            'list_adapters': LaunchConfiguration('list_adapters'),
            'control_frequency': LaunchConfiguration('control_frequency'),
        }],
        condition=UnlessCondition(LaunchConfiguration('list_adapters'))
    )
    
    # 仅列出适配器的节点（不进行控制）
    list_adapters_node = Node(
        package='soem_ethercat_motor',
        executable='ecat_motor_control_node',
        name='ecat_adapter_lister',
        output='screen',
        parameters=[{
            'list_adapters': True,
        }],
        condition=IfCondition(LaunchConfiguration('list_adapters'))
    )
    
    # 信息提示
    info_msg = LogInfo(
        msg=[
            'EtherCAT电机控制节点启动参数:\n',
            '  adapter_name: ', LaunchConfiguration('adapter_name'), '\n',
            '  slave_index: ', LaunchConfiguration('slave_index'), '\n',
            '  target_position: ', LaunchConfiguration('target_position'), '\n',
            '  control_frequency: ', LaunchConfiguration('control_frequency'), ' Hz\n',
            '注意: 需要sudo权限或设置cap_net_raw权限'
        ]
    )
    
    return LaunchDescription([
        adapter_name_arg,
        slave_index_arg,
        target_position_arg,
        list_adapters_arg,
        control_frequency_arg,
        info_msg,
        ecat_motor_node,
        list_adapters_node,
    ])