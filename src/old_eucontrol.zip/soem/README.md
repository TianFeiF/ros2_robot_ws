# SOEM EtherCAT 主站电机控制 - ROS2 Humble 包

本工程是基于 SOEM（Simple Open EtherCAT Master）的 ROS2 Humble 包，实现 EtherCAT 主站电机控制功能。通过 CiA‑402（伺服驱动）协议进行电机使能与位置控制，并提供完整的 ROS2 接口。

## 功能概览
- **ROS2 节点**：完整的 ROS2 节点实现，支持参数配置和话题通信
- **EtherCAT 主站**：列出可用网卡、扫描配置从站、进入 OP 状态
- **CiA-402 控制**：通过 SDO 设置 Profile Position 模式并发送位置命令
- **ROS2 接口**：
  - 发布电机状态和关节状态信息
  - 订阅速度命令并转换为位置控制
  - 支持参数动态配置
- **Launch 文件**：提供便捷的启动配置

> 说明：当前版本使用 SDO 进行控制，便于入门与调试；实际项目为提升性能与实时性，建议改为 PDO 周期发送。

## 环境准备（ROS2 Humble + Ubuntu 22.04）

### 1. 安装 ROS2 Humble
```bash
# 如果尚未安装 ROS2 Humble，请参考官方文档
sudo apt update
sudo apt install -y ros-humble-desktop
```

### 2. 安装依赖
```bash
sudo apt install -y git build-essential cmake libcap2-bin
sudo apt install -y ros-humble-rclcpp ros-humble-std-msgs ros-humble-geometry-msgs ros-humble-sensor-msgs
```

### 3. 设置 ROS2 环境
```bash
source /opt/ros/humble/setup.bash
```

## 构建步骤（ROS2 方式）

### 1. 在 ROS2 工作空间中构建
```bash
# 进入你的 ROS2 工作空间
cd ~/ros2_ws

# 构建包
colcon build --packages-select soem_ethercat_motor

# 设置环境
source install/setup.bash
```

### 2. 传统 CMake 构建（仅用于测试）
```bash
mkdir -p build && cd build
cmake -DSOEM_FETCH=ON ..
cmake --build . -j
```

## ROS2 使用方法

### 1. 列出可用适配器
```bash
# 使用 launch 文件
ros2 launch soem_ethercat_motor list_adapters.launch.py

# 或直接运行节点
ros2 run soem_ethercat_motor ecat_motor_control_node --ros-args -p list_adapters:=true
```

### 2. 启动 EtherCAT 电机控制节点
```bash
# 使用 launch 文件（推荐）
sudo ros2 launch soem_ethercat_motor ecat_motor_control.launch.py adapter_name:=enp3s0 slave_index:=1

# 或直接运行节点
sudo ros2 run soem_ethercat_motor ecat_motor_control_node --ros-args -p adapter_name:=enp3s0 -p slave_index:=1
```

### 3. 使用配置文件启动
```bash
# 修改 config/ecat_motor_params.yaml 中的参数
sudo ros2 run soem_ethercat_motor ecat_motor_control_node --ros-args --params-file src/soem_ethercat_motor/config/ecat_motor_params.yaml
```

### 4. 发送控制命令
```bash
# 发送速度命令（会转换为位置控制）
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 1.0, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}"
```

### 5. 监控状态
```bash
# 查看电机状态
ros2 topic echo /ecat_status

# 查看关节状态
ros2 topic echo /joint_states
```

## ROS2 接口说明

### 话题 (Topics)
- **发布者**：
  - `/ecat_status` (std_msgs/String): EtherCAT 电机状态信息
  - `/joint_states` (sensor_msgs/JointState): 关节状态信息
- **订阅者**：
  - `/cmd_vel` (geometry_msgs/Twist): 速度命令输入

### 参数 (Parameters)
- `adapter_name` (string): EtherCAT 网卡适配器名称
- `slave_index` (int): 从站序号，默认为 1
- `target_position` (int): 初始目标位置，默认为 10000
- `control_frequency` (double): 控制循环频率，默认为 100.0 Hz
- `list_adapters` (bool): 是否仅列出适配器，默认为 false

## 权限设置

### 方法1：使用 sudo（推荐用于测试）
```bash
sudo ros2 launch soem_ethercat_motor ecat_motor_control.launch.py adapter_name:=enp3s0
```

### 方法2：设置 cap_net_raw 权限
```bash
# 构建后设置权限
sudo setcap cap_net_raw+ep install/soem_ethercat_motor/lib/soem_ethercat_motor/ecat_motor_control_node

# 然后可以不用 sudo 运行
ros2 launch soem_ethercat_motor ecat_motor_control.launch.py adapter_name:=enp3s0
```

## 接线与网络注意事项
- EtherCAT 拓扑需正确（主站网口直连到第一个从站，级联其余从站）。
- 运行时避免该网卡被普通 IP 网络占用；建议专用口跑总线。
- 禁用网卡节能或某些节流机制以提升实时性（视硬件与驱动）。

## CiA‑402 提示
- 本示例通过 SDO 写入：
  - 模式（6060h）= 1（Profile Position）
  - 控制字（6040h）执行 Shutdown → Switch on → Enable operation
  - 目标位置（607Ah）与新设定点触发（6040h bit4）
- 驱动的默认 PDO/SDO 映射与行为可能不同，请查阅具体驱动手册并调整索引、位定义与时序。
- 实际工程建议：在 PRE‑OP/SAFE‑OP 阶段完成 PDO 映射，进入 OP 后通过 PDO 周期写入控制字/目标值并读取状态字/位置等实时数据。

## 移植指南
- 目标仍为 Linux（不同发行版）：
  - 继续使用 SOEM 的 `oshw/posix` 实现，检查网卡名与权限配置即可。
- 嵌入式 Linux / RT‑Linux：
  - 保持 SOEM 主站不变，重点在调度（`sched_setscheduler`、`chrt`）与线程优先级、周期（定时器/高精度时钟）。
- 非 Linux 平台（如 RTOS/自研平台）：
  - 使用 SOEM 的移植层接口（OSAL/OSHW）；需实现底层网卡收发、时间与互斥等。
  - 参考 SOEM `oshw` 目录已有平台示例来完成网卡驱动适配。
- 架构建议：
  - 将总线初始化、扫描与状态机封装为模块；周期任务（发送/接收）与控制轨迹规划分离。
  - 保持与 SOEM API 的边界清晰，移植时仅替换 OSHW/OSAL 层与线程/定时部分。

## 常见问题
- `ec_init失败`：检查适配器名是否正确、是否有 `sudo` 或 `cap_net_raw` 权限。
- `未发现从站`：检查物理连接、从站电源、网线与拓扑；确认主站网口未跑普通 IP 网络。
- `进入OP失败`：从站映射或驱动状态不满足；尝试在 PRE‑OP/SAFE‑OP 阶段完成 SDO 配置后再进入 OP。
- 位置不动作：驱动使能条件、限位、急停或模式不匹配；确认 6060h、6040h 与 6041h 的位状态与错误码。

## 项目结构
```
soem_ethercat_motor/
├── CMakeLists.txt              # ROS2 ament_cmake 构建文件
├── package.xml                 # ROS2 包描述文件
├── README.md                   # 本文档
├── config/                     # 配置文件目录
│   └── ecat_motor_params.yaml  # 默认参数配置
├── launch/                     # Launch 文件目录
│   ├── ecat_motor_control.launch.py  # 主启动文件
│   └── list_adapters.launch.py       # 适配器列表启动文件
├── scripts/                    # 脚本目录
│   └── setup_ubuntu.sh        # Ubuntu 环境设置脚本
└── src/                        # 源码目录
    ├── main.cpp                # ROS2 节点主程序
    └── main.c                  # 原始 C 代码（保留作参考）
```

## 开发与调试

### 1. 查看节点信息
```bash
# 查看节点列表
ros2 node list

# 查看节点信息
ros2 node info /ecat_motor_control_node

# 查看参数
ros2 param list /ecat_motor_control_node
```

### 2. 话题调试
```bash
# 查看话题列表
ros2 topic list

# 查看话题信息
ros2 topic info /ecat_status
ros2 topic info /joint_states

# 实时监控话题
ros2 topic hz /joint_states
```

### 3. 日志调试
```bash
# 设置日志级别
ros2 run soem_ethercat_motor ecat_motor_control_node --ros-args --log-level DEBUG
```

## 故障排除

### 常见问题
1. **`ec_init失败`**：
   - 检查适配器名是否正确
   - 确认是否有 `sudo` 权限或 `cap_net_raw` 权限
   - 检查网卡是否被其他程序占用

2. **`未发现从站`**：
   - 检查物理连接和从站电源
   - 确认 EtherCAT 拓扑正确
   - 检查网线质量和连接

3. **`进入OP失败`**：
   - 检查从站配置和映射
   - 在 PRE-OP/SAFE-OP 阶段完成 SDO 配置

4. **ROS2 节点无法启动**：
   - 确认 ROS2 环境已正确设置
   - 检查依赖包是否安装完整
   - 查看详细错误日志

### 性能优化建议
- 对于实时性要求高的应用，建议：
  - 使用 PDO 替代 SDO 进行周期性数据交换
  - 配置实时内核和调度策略
  - 优化控制循环频率和网络参数

## 扩展开发

### 添加新的电机类型
1. 在 `main.cpp` 中扩展 CiA-402 控制逻辑
2. 添加对应的参数配置
3. 更新 launch 文件和配置文件

### 集成到更大的系统
- 可以作为 ROS2 组件集成到机器人系统中
- 支持与 MoveIt、Navigation2 等框架集成
- 提供标准的 ROS2 接口便于系统集成

## 许可与致谢
- **SOEM**: 由 OpenEtherCAT Society 开源提供，详见其仓库与许可说明
- **ROS2**: 遵循 Apache 2.0 许可证
- 本包仅为教学与集成参考，请根据实际驱动与安全规范完善

## 贡献
欢迎提交 Issue 和 Pull Request 来改进本项目。请确保：
- 遵循 ROS2 编码规范
- 添加适当的测试和文档
- 保持向后兼容性