#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <cmath>
#include <csignal>
#include <mutex>
#include <thread>
#include <chrono>
#include <vector>
#include <map>
#include "../include/eu_ethercat.h"
#include "eu_motor_control/msg/operate_mode.hpp"
#include "eu_motor_control/msg/emergency_control.hpp"

// 电机数据结构
struct MotorData
{
    huint16 slave_id;
    bool enabled;
    eth_OperateMode operate_mode;
    hint32 current_target_position;
    hint32 current_target_velocity;
    hint16 current_target_torque;
    std::string joint_name;
};

class EuMotorControllerNode : public rclcpp::Node
{
public:
    EuMotorControllerNode() : Node("eu_motor_controller_node")
    {
        // 电机参数
        pulse_per_revolution_ = 6619136;  // 电机脉冲数
        cycle_time_ms_ = 5;  // 循环时间5ms (200Hz)
        
        // 初始化EtherCAT
        if (!initEtherCAT())
        {
            RCLCPP_ERROR(this->get_logger(), "Failed to initialize EtherCAT");
            rclcpp::shutdown();
            return;
        }
        
        // 为每个检测到的电机创建数据结构
        setupMotors();
        // 初始化要求：电机1目标位置设置为当前位置，但不使能
        if (slave_count_ >= 1)
        {
            hint32 actual_pos = 0;
            int ret = eth_getActualPosition(static_cast<huint16>(1), &actual_pos);
            if (ret == ETH_SUCCESS)
            {
                int sret = eth_setTargetPosition(static_cast<huint16>(1), actual_pos);
                if (sret == ETH_SUCCESS)
                {
                    motors_[1].current_target_position = actual_pos;
                    RCLCPP_INFO(this->get_logger(), "Init: motor 1 target set to current position %d (no enable)", actual_pos);
                }
                else
                {
                    RCLCPP_WARN(this->get_logger(), "Init: failed to set target position for motor 1 to %d", actual_pos);
                }
            }
            else
            {
                RCLCPP_WARN(this->get_logger(), "Init: failed to read actual position for motor 1");
            }
        }
 
        // 创建话题订阅者和发布者
        setupTopics();
            
        // 创建定时器用于发布反馈和状态
        feedback_timer_ = this->create_wall_timer(
            std::chrono::milliseconds(cycle_time_ms_),
            std::bind(&EuMotorControllerNode::publishFeedback, this));
            
        RCLCPP_INFO(this->get_logger(), "EU Motor Controller Node started with %d motors", slave_count_);
    }
    
    ~EuMotorControllerNode()
    {
        // 停止所有电机并释放资源
        for (auto& motor : motors_)
        {
            if (motor.second.enabled)
            {
                eth_disable(motor.second.slave_id);
            }
        }
        eth_freeDLL();
        RCLCPP_INFO(this->get_logger(), "EtherCAT resources released");
    }
    
private:
    bool initEtherCAT()
    {
        // 初始化EtherCAT主站
        if (ETH_SUCCESS != eth_initDLL("enp1s0", cycle_time_ms_, &slave_count_))
        {
            RCLCPP_ERROR(this->get_logger(), "Failed to initialize EtherCAT DLL");
            return false;
        }
        
        RCLCPP_INFO(this->get_logger(), "Found %d slaves", slave_count_);
        return true;
    }

    int resetFaults(huint16 sid)
    {
        huint16 fault_reset = 0x0080;
        int ret = eth_writeSDO(sid, 0x6040, 0x00, &fault_reset, eth_DataType_uint16, 1000);
        if (ret != ETH_SUCCESS)
        {
            RCLCPP_ERROR(this->get_logger(), "Failed to reset faults for slave %d", sid);
        }
        else RCLCPP_INFO(this->get_logger(), "Reset faults for slave %d", sid);
        // 等待故障重置完成
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        if(sid ==1)
        {
            int CyclicSyncPosition = 8;
            if (ETH_SUCCESS != eth_writeSDO(sid, 0x6060, 0x00, &CyclicSyncPosition, eth_DataType_uint8, 1000))
            {
                RCLCPP_ERROR(this->get_logger(), "Failed to set operate mode for slave %d", sid);
            }
            else RCLCPP_INFO(this->get_logger(), "Set operate mode for slave %d", sid);
            uint8_t control_word = 0x06;
            if (ETH_SUCCESS != eth_writeSDO(sid, 0x6040, 0x00, &control_word, eth_DataType_uint8, 1000))
            {
                RCLCPP_ERROR(this->get_logger(), "Failed to enable slave %d", sid);
            }
            else RCLCPP_INFO(this->get_logger(), "Enabled slave %d", sid);
            control_word = 0x07;
            if (ETH_SUCCESS != eth_writeSDO(sid, 0x6040, 0x00, &control_word, eth_DataType_uint8, 1000))
            {
                RCLCPP_ERROR(this->get_logger(), "Failed to set control word for slave %d", sid);
            }
            else RCLCPP_INFO(this->get_logger(), "Set control word for slave %d", sid);
            control_word = 0x0F;
            if (ETH_SUCCESS != eth_writeSDO(sid, 0x6040, 0x00, &control_word, eth_DataType_uint8, 1000))
            {
                RCLCPP_ERROR(this->get_logger(), "Failed to set control word for slave %d", sid);
            }
            else RCLCPP_INFO(this->get_logger(), "Set control word for slave %d", sid);

        }
        eth_enable(sid);
        return ret;
    }
    
    void setupMotors()
    {
        // 为每个从站创建电机数据结构
        for (int i = 1; i <= slave_count_; i++)
        {
            MotorData motor;
            motor.slave_id = static_cast<huint16>(i);
            motor.enabled = false;
            motor.operate_mode = eth_OperateMode_Reserve;  // 默认保留模式
            motor.current_target_position = 0;
            motor.current_target_velocity = 0;
            motor.current_target_torque = 0;
            motor.joint_name = "motor_" + std::to_string(i);
            
            motors_[i] = motor;
            
            RCLCPP_INFO(this->get_logger(), "Motor %d created: %s", i, motor.joint_name.c_str());
        }
    }
    
    void setupTopics()
    {
        // 操作模式相关话题
        operate_mode_cmd_sub_ = this->create_subscription<eu_motor_control::msg::OperateMode>(
            "/motor_control/operate_mode_cmd", 10,
            std::bind(&EuMotorControllerNode::operateModeCmdCallback, this, std::placeholders::_1));
        
        operate_mode_state_pub_ = this->create_publisher<eu_motor_control::msg::OperateMode>(
            "/motor_control/operate_mode_state", 10);
        
        // 电机控制相关话题
        motor_cmd_sub_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "/motor_control/motor_cmd", 10,
            std::bind(&EuMotorControllerNode::motorCmdCallback, this, std::placeholders::_1));
        
        motor_state_pub_ = this->create_publisher<sensor_msgs::msg::JointState>(
            "/motor_control/motor_state", 10);
        
        // 紧急控制相关话题
        emg_cmd_sub_ = this->create_subscription<eu_motor_control::msg::EmergencyControl>(
            "/motor_control/emg_cmd", 10,
            std::bind(&EuMotorControllerNode::emergencyCmdCallback, this, std::placeholders::_1));
        
        emg_state_pub_ = this->create_publisher<eu_motor_control::msg::EmergencyControl>(
            "/motor_control/emg_state", 10);
    }
    
    
    void operateModeCmdCallback(const eu_motor_control::msg::OperateMode::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(motor_mutex_);
        
        // 根据name找到对应的电机
        int motor_id = extractMotorId(msg->name);
        if (motor_id < 0 || motors_.find(motor_id) == motors_.end())
        {
            RCLCPP_WARN(this->get_logger(), "Invalid motor name: %s", msg->name.c_str());
            return;
        }
        
        MotorData& motor = motors_[motor_id];
        
        // 设置操作模式
        eth_OperateMode new_mode = static_cast<eth_OperateMode>(msg->operate_mode);
        if (ETH_SUCCESS == eth_setOperateMode(motor.slave_id, new_mode))
        {
            motor.operate_mode = new_mode;
            RCLCPP_INFO(this->get_logger(), "Motor %s: Set operate mode to %d", 
                       msg->name.c_str(), msg->operate_mode);
        }
        else
        {
            RCLCPP_ERROR(this->get_logger(), "Motor %s: Failed to set operate mode to %d", 
                        msg->name.c_str(), msg->operate_mode);
        }
        
        // 处理使能状态
        if (msg->enable_state && !motor.enabled)
        {
            if (ETH_SUCCESS == eth_enable(motor.slave_id))
            {
                motor.enabled = true;
                RCLCPP_INFO(this->get_logger(), "Motor %s: Enabled", msg->name.c_str());
            }
            else
            {
                RCLCPP_ERROR(this->get_logger(), "Motor %s: Failed to enable", msg->name.c_str());
            }
        }
        else if (!msg->enable_state && motor.enabled)
        {
            if (ETH_SUCCESS == eth_disable(motor.slave_id))
            {
                motor.enabled = false;
                RCLCPP_INFO(this->get_logger(), "Motor %s: Disabled", msg->name.c_str());
            }
            else
            {
                RCLCPP_ERROR(this->get_logger(), "Motor %s: Failed to disable", msg->name.c_str());
            }
        }
        
        // 发布操作模式状态
        publishOperateModeState(motor_id);
    }
    
    void motorCmdCallback(const sensor_msgs::msg::JointState::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(motor_mutex_);
        
        if (msg->name.size() != msg->position.size())
        {
            RCLCPP_WARN(this->get_logger(), "Joint names and positions size mismatch");
            return;
        }
        
        for (size_t i = 0; i < msg->name.size(); i++)
        {
            int motor_id = extractMotorId(msg->name[i]);
            if (motor_id < 0 || motors_.find(motor_id) == motors_.end())
            {
                RCLCPP_WARN(this->get_logger(), "Unknown motor name: %s", msg->name[i].c_str());
                continue;
            }
            
            MotorData& motor = motors_[motor_id];
            
            // if (!motor.enabled)
            // {
            //     RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 1000,
            //                         "Motor %s not enabled, ignoring command", msg->name[i].c_str());
            //     continue;
            // }
            
            // 根据操作模式选择控制方法（仅支持同步模式）
            switch (motor.operate_mode)
            {
                case eth_OperateMode_CyclicSyncPosition:
                {
                    // 同步位置控制
                    double target_angle_rad = msg->position[i];
                    hint32 target_position_pulse = static_cast<hint32>(target_angle_rad * pulse_per_revolution_ / (2.0 * M_PI));
                    
                    if (ETH_SUCCESS == eth_setTargetPosition(motor.slave_id, target_position_pulse))
                    {
                        motor.current_target_position = target_position_pulse;
                        // RCLCPP_INFO(this->get_logger(), "Motor %s: Set target position: %.3f rad (%d pulses)", 
                        //             msg->name[i].c_str(), target_angle_rad, target_position_pulse);
                        RCLCPP_DEBUG(this->get_logger(), "Motor %s: Set target position: %.3f rad (%d pulses)", 
                                    msg->name[i].c_str(), target_angle_rad, target_position_pulse);
                    }
                    else
                    {
                        RCLCPP_ERROR(this->get_logger(), "Motor %s: Failed to set target position", msg->name[i].c_str());
                    }
                    break;
                }
                
                case eth_OperateMode_CyclicSyncVelocity:
                {
                    // 同步速度控制（使用velocity字段如果存在）
                    double target_velocity_rad_s = (i < msg->velocity.size()) ? msg->velocity[i] : 0.0;
                    hint32 target_velocity_pulse = static_cast<hint32>(target_velocity_rad_s * pulse_per_revolution_ / (2.0 * M_PI));
                    
                    if (ETH_SUCCESS == eth_setTargetVelocity(motor.slave_id, target_velocity_pulse))
                    {
                        motor.current_target_velocity = target_velocity_pulse;
                        RCLCPP_DEBUG(this->get_logger(), "Motor %s: Set target velocity: %.3f rad/s (%d pulses/s)", 
                                    msg->name[i].c_str(), target_velocity_rad_s, target_velocity_pulse);
                    }
                    else
                    {
                        RCLCPP_ERROR(this->get_logger(), "Motor %s: Failed to set target velocity", msg->name[i].c_str());
                    }
                    break;
                }
                
                case eth_OperateMode_CyclicSyncTorque:
                {
                    // 同步力矩控制（使用effort字段如果存在）
                    double target_torque_nm = (i < msg->effort.size()) ? msg->effort[i] : 0.0;
                    // 假设额定力矩为9.6Nm，转换为千分之
                    hint16 target_torque_per_mille = static_cast<hint16>(target_torque_nm / 5.0 * 1000);
                    
                    if (ETH_SUCCESS == eth_setTargetTorque(motor.slave_id, target_torque_per_mille))
                    {
                        motor.current_target_torque = target_torque_per_mille;
                        RCLCPP_DEBUG(this->get_logger(), "Motor %s: Set target torque: %.3f Nm (%d per_mille)", 
                                    msg->name[i].c_str(), target_torque_nm, target_torque_per_mille);
                    }
                    else
                    {
                        RCLCPP_ERROR(this->get_logger(), "Motor %s: Failed to set target torque", msg->name[i].c_str());
                    }
                    break;
                }
                
                default:
                    RCLCPP_WARN(this->get_logger(), "Motor %s: Only CyclicSync modes (8,9,10) are supported, current mode: %d", 
                               msg->name[i].c_str(), static_cast<int>(motor.operate_mode));
                    break;
            }
        }
    }
    
    void emergencyCmdCallback(const eu_motor_control::msg::EmergencyControl::SharedPtr msg)
    {
        std::lock_guard<std::mutex> lock(motor_mutex_);
        
        auto response = std::make_shared<eu_motor_control::msg::EmergencyControl>();
        response->names = msg->names;
        response->slave_ids = msg->slave_ids;
        response->command_type = msg->command_type;
        response->success = true;
        
        switch (msg->command_type)
        {
            case 1: // 获取状态
            {
                response->slave_states.clear();
                for (size_t i = 0; i < msg->slave_ids.size(); i++)
                {
                    const huint16 sid = static_cast<huint16>(msg->slave_ids[i]);
                    if (sid == 0 || sid > static_cast<huint16>(slave_count_)) {
                        response->slave_states.push_back(-1);
                        response->success = false;
                        RCLCPP_WARN(this->get_logger(), "Skip get state: invalid slave id %d (slave_count=%d)", msg->slave_ids[i], slave_count_);
                        continue;
                    }
                    eth_State state;
                    if (ETH_SUCCESS == eth_getSlaveState(sid, &state))
                    {
                        response->slave_states.push_back(static_cast<int32_t>(state));
                    }
                    else
                    {
                        response->slave_states.push_back(-1);  // 错误状态
                        response->success = false;
                        RCLCPP_ERROR(this->get_logger(), "Failed to get state for slave %d", sid);
                    }
                }
                break;
            }
            
            case 2: // 故障重置
            {
                for (size_t i = 0; i < msg->slave_ids.size(); i++)
                {
                    const huint16 sid = static_cast<huint16>(msg->slave_ids[i]);
                    if (sid == 0 || sid > static_cast<huint16>(slave_count_)) {
                        response->success = false;
                        RCLCPP_WARN(this->get_logger(), "Skip fault reset: invalid slave id %d (slave_count=%d)", msg->slave_ids[i], slave_count_);
                        continue;
                    }
                    if (ETH_SUCCESS != resetFaults(sid))
                    {
                        response->success = false;
                        RCLCPP_ERROR(this->get_logger(), "Failed to reset fault for slave %d", sid);
                    }
                    else
                    {
                        RCLCPP_INFO(this->get_logger(), "Fault reset for slave %d", sid);
                    }
                }
                break;
            }
            
            case 3: // 快速停机
            {
                for (size_t i = 0; i < msg->slave_ids.size(); i++)
                {
                    const huint16 sid = static_cast<huint16>(msg->slave_ids[i]);
                    if (sid == 0 || sid > static_cast<huint16>(slave_count_)) {
                        response->success = false;
                        RCLCPP_WARN(this->get_logger(), "Skip quick stop: invalid slave id %d (slave_count=%d)", msg->slave_ids[i], slave_count_);
                        continue;
                    }
                    if (ETH_SUCCESS != eth_quickStop(sid))
                    {
                        response->success = false;
                        RCLCPP_ERROR(this->get_logger(), "Failed to quick stop for slave %d", sid);
                    }
                    else
                    {
                        RCLCPP_INFO(this->get_logger(), "Quick stop executed for slave %d", sid);
                    }
                }
                break;
            }
            
            default:
                RCLCPP_WARN(this->get_logger(), "Unknown emergency command type: %d", msg->command_type);
                response->success = false;
                break;
        }
        
        // 发布响应
        emg_state_pub_->publish(*response);
    }
    
    
    void publishFeedback()
    {
        std::lock_guard<std::mutex> lock(motor_mutex_);
        
        // 发布电机状态
        publishMotorState();
        
        // 定期发布操作模式状态
        static int counter = 0;
        if (++counter % 40 == 0)  // 每200ms发布一次操作模式状态 (5ms * 40 = 200ms)
        {
            for (const auto& motor_pair : motors_)
            {
                publishOperateModeState(motor_pair.first);
            }
        }
    }
    
    void publishMotorState()
    {
        auto motor_state_msg = sensor_msgs::msg::JointState();
        motor_state_msg.header.stamp = this->get_clock()->now();
        motor_state_msg.header.frame_id = "base_link";

        // 总是为每个电机发布一行；未使能时也尝试读取，读失败则使用0占位
        for (const auto& motor_pair : motors_)
        {
            const MotorData& motor = motor_pair.second;

            double position_rad = 0.0;
            double velocity_rad_s = 0.0;
            double torque_nm = 0.0;

            // 无论是否使能，都读取从站反馈（某些驱动在未使能时也可读到实际量）
            hint32 actual_position = 0;
            hint32 actual_velocity = 0;
            hint16 actual_torque = 0;

            bool position_ok = (ETH_SUCCESS == eth_getActualPosition(motor.slave_id, &actual_position));
            bool velocity_ok = (ETH_SUCCESS == eth_getActualVelocity(motor.slave_id, &actual_velocity));
            bool torque_ok = (ETH_SUCCESS == eth_getActualTorque(motor.slave_id, &actual_torque));

            if (!position_ok || !velocity_ok || !torque_ok)
            {
                RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 1000,
                                     "Motor %s: Failed to read feedback data", motor.joint_name.c_str());
            }
            else
            {
                position_rad = static_cast<double>(actual_position) * 2.0 * M_PI / pulse_per_revolution_;
                            // 针对motor_1的位置反馈应用0.6系数
                if (motor.joint_name == "motor_1") {
                    position_rad *= 0.6;
                    RCLCPP_DEBUG(this->get_logger(), "Motor_1 position feedback scaled by 0.6: %.3f rad", position_rad);
                }
                velocity_rad_s = static_cast<double>(actual_velocity) * 2.0 * M_PI / pulse_per_revolution_;
                torque_nm = static_cast<double>(actual_torque) / 1000.0 * 5.0;  // 额定力矩换算
            }

            motor_state_msg.name.push_back(motor.joint_name);
            motor_state_msg.position.push_back(position_rad);
            motor_state_msg.velocity.push_back(velocity_rad_s);
            motor_state_msg.effort.push_back(torque_nm);
        }

        motor_state_pub_->publish(motor_state_msg);
    }
    
    void publishOperateModeState(int motor_id)
    {
        const MotorData& motor = motors_[motor_id];
        
        // 直接使用存储的操作模式，因为API参数不是指针类型
        auto msg = eu_motor_control::msg::OperateMode();
        msg.name = motor.joint_name;
        msg.operate_mode = static_cast<int32_t>(motor.operate_mode);
        msg.enable_state = motor.enabled;
        
        operate_mode_state_pub_->publish(msg);
    }
    
    int extractMotorId(const std::string& name)
    {
        if (name.find("motor_") == 0)
        {
            try {
                return std::stoi(name.substr(6));
            } catch (const std::exception& e) {
                RCLCPP_WARN(this->get_logger(), "Invalid motor name format: %s", name.c_str());
                return -1;
            }
        }
        return -1;
    }
    
    // 成员变量
    int slave_count_;
    int pulse_per_revolution_;
    int cycle_time_ms_;
    std::mutex motor_mutex_;
    
    // 电机管理
    std::map<int, MotorData> motors_;
    
    // ROS2组件
    rclcpp::TimerBase::SharedPtr feedback_timer_;
    
    // 操作模式相关
    rclcpp::Subscription<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_cmd_sub_;
    rclcpp::Publisher<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_state_pub_;
    
    // 电机控制相关
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr motor_cmd_sub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr motor_state_pub_;
    
    // 紧急控制相关
    rclcpp::Subscription<eu_motor_control::msg::EmergencyControl>::SharedPtr emg_cmd_sub_;
    rclcpp::Publisher<eu_motor_control::msg::EmergencyControl>::SharedPtr emg_state_pub_;
};

// 信号处理函数
std::shared_ptr<EuMotorControllerNode> g_node = nullptr;

void signalHandler(int signal)
{
    if (g_node)
    {
        RCLCPP_INFO(g_node->get_logger(), "Received signal %d, shutting down...", signal);
    }
    rclcpp::shutdown();
}

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    
    // 设置信号处理
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    
    try
    {
        g_node = std::make_shared<EuMotorControllerNode>();
        rclcpp::spin(g_node);
    }
    catch (const std::exception& e)
    {
        RCLCPP_ERROR(rclcpp::get_logger("main"), "Exception: %s", e.what());
    }
    
    g_node.reset();
    rclcpp::shutdown();
    return 0;
}
