#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # 获取包路径
    pkg_dir = get_package_share_directory('eu_motor_control')
    
    return LaunchDescription([
        # RViz2节点 - 加载电机控制插件
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2_motor_control',
            output='screen',
            parameters=[{'use_sim_time': False}]
        ),
        
        # 电机UI节点（可选，如果想同时使用独立UI和RViz插件）
        # Node(
        #     package='eu_motor_control',
        #     executable='motor_ui.py',
        #     name='motor_ui_node',
        #     output='screen'
        # )
    ])
