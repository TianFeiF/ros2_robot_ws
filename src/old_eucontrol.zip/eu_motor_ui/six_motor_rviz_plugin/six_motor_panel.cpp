#include "six_motor_panel.hpp"
#include <pluginlib/class_list_macros.hpp>
#include <QScrollArea>
#include <QDateTime>
#include <QtGlobal>
#include <algorithm>
#include <cmath>

namespace eu_motor_control
{

SixMotorPanel::SixMotorPanel(QWidget* parent)
    : rviz_common::Panel(parent)
{
    setupMotorConfigs();
    setupUI();
}

SixMotorPanel::~SixMotorPanel()
{
    if (status_timer_) status_timer_->stop();
}

void SixMotorPanel::onInitialize()
{
    // 获取RViz的ROS节点
    auto ctx = getDisplayContext()->getRosNodeAbstraction().lock();
    if (ctx) {
        node_ = ctx->get_raw_node();
    } else {
        if (!rclcpp::ok()) rclcpp::init(0, nullptr);
        node_ = rclcpp::Node::make_shared("six_motor_rviz_panel");
    }

    setupROS();

    status_timer_ = new QTimer(this);
    connect(status_timer_, &QTimer::timeout, this, &SixMotorPanel::updateStatus);
    status_timer_->start(100);
}

void SixMotorPanel::save(rviz_common::Config config) const
{
    rviz_common::Panel::save(config);
}

void SixMotorPanel::load(const rviz_common::Config& config)
{
    rviz_common::Panel::load(config);
}

// ========================= UI 构建 =========================
void SixMotorPanel::setupMotorConfigs()
{
    motor_configs_.clear();
    // 1 位置，2&3 速度，4&5 力矩，预留6
    motor_configs_.push_back({1, "motor_1", 8, "位置(8)", false, true});
    motor_configs_.push_back({2, "motor_2", 9, "速度(9)", false, true});
    motor_configs_.push_back({3, "motor_3", 9, "速度(9)", false, true});
    motor_configs_.push_back({4, "motor_4", 10, "力矩(10)", false, true});
    motor_configs_.push_back({5, "motor_5", 10, "力矩(10)", false, true});
    motor_configs_.push_back({6, "motor_6", 8, "位置(8)", false, true});
}

void SixMotorPanel::setupUI()
{
    main_layout_ = new QVBoxLayout(this);

    tab_widget_ = new QTabWidget(this);
    main_layout_->addWidget(tab_widget_);

    setupInitTab();
    setupPositionTab();
    setupVelocityTab();
    setupTorqueTab();
    setupMonitorTab();
    setupEmergencyTab();
}

void SixMotorPanel::setupInitTab()
{
    init_tab_ = new QWidget(this);
    init_layout_ = new QVBoxLayout(init_tab_);

    init_group_ = new QGroupBox("初始化与模式设置", init_tab_);
    // 使用单一的VBox作为group布局；grid不直接绑定到group，避免重复设置布局导致崩溃
    init_grid_ = new QGridLayout();

    init_grid_->addWidget(new QLabel("电机"), 0, 0);
    init_grid_->addWidget(new QLabel("模式"), 0, 1);
    init_grid_->addWidget(new QLabel("使能"), 0, 2);
    init_grid_->addWidget(new QLabel("操作"), 0, 3);
    init_grid_->addWidget(new QLabel("状态"), 0, 4);

    int row = 1;
    for (const auto& mc : motor_configs_) {
        init_grid_->addWidget(new QLabel(QString::fromStdString(mc.name)), row, 0);
        init_grid_->addWidget(new QLabel(QString::fromStdString(mc.mode_name)), row, 1);
        QCheckBox* enable_cb = new QCheckBox("使能");
        enable_cb->setChecked(true);
        init_grid_->addWidget(enable_cb, row, 2);

        QPushButton* set_btn = new QPushButton("设置模式");
        init_grid_->addWidget(set_btn, row, 3);
        QLabel* status_lbl = new QLabel("未初始化");
        init_grid_->addWidget(status_lbl, row, 4);

        // 存储控件引用（按ID）
        motor_init_buttons_[mc.id] = set_btn;
        motor_init_status_labels_[mc.id] = status_lbl;

        connect(set_btn, &QPushButton::clicked, this, [this, id=mc.id, enable_cb]() {
            setMotorOperateMode(id, enable_cb->isChecked());
        });

        row++;
    }

    init_all_button_ = new QPushButton("全部设置/初始化");
    connect(init_all_button_, &QPushButton::clicked, this, &SixMotorPanel::onInitializeAllMotors);
    init_progress_ = new QProgressBar();
    init_progress_->setRange(0, static_cast<int>(motor_configs_.size()));
    init_progress_->setValue(0);
    overall_status_label_ = new QLabel("等待初始化...");

    QHBoxLayout* bottom = new QHBoxLayout();
    bottom->addWidget(init_all_button_);
    bottom->addWidget(init_progress_);
    bottom->addWidget(overall_status_label_);

    QVBoxLayout* v = new QVBoxLayout(init_group_);
    v->addLayout(init_grid_);
    v->addLayout(bottom);

    init_layout_->addWidget(init_group_);

    tab_widget_->addTab(init_tab_, "初始化");
}

void SixMotorPanel::setupPositionTab()
{
    position_tab_ = new QWidget(this);
    position_layout_ = new QVBoxLayout(position_tab_);

    position_control_group_ = new QGroupBox("电机1 - 位置状态 (插件内禁止控制)", position_tab_);
    QGridLayout* grid = new QGridLayout(position_control_group_);
    // 禁止通过插件控制电机1，仅保留只读状态显示
    QLabel* note = new QLabel("提示：电机1的目标位置由上位控制，不可在此修改。", position_control_group_);
    note->setStyleSheet("color:#888");
    grid->addWidget(note, 0, 0, 1, 2);

    position_status_group_ = new QGroupBox("状态", position_tab_);
    QGridLayout* status_grid = new QGridLayout(position_status_group_);
    status_grid->addWidget(new QLabel("当前角度:"), 0, 0);
    position_current_label_ = new QLabel("0.000");
    status_grid->addWidget(position_current_label_, 0, 1);
    status_grid->addWidget(new QLabel("目标角度:"), 1, 0);
    position_target_label_ = new QLabel("0.000");
    status_grid->addWidget(position_target_label_, 1, 1);
    status_grid->addWidget(new QLabel("模式状态:"), 2, 0);
    position_mode_status_label_ = new QLabel("未设置");
    status_grid->addWidget(position_mode_status_label_, 2, 1);

    position_layout_->addWidget(position_control_group_);
    position_layout_->addWidget(position_status_group_);

    tab_widget_->addTab(position_tab_, "位置(1)");
}

void SixMotorPanel::setupVelocityTab()
{
    velocity_tab_ = new QWidget(this);
    velocity_layout_ = new QVBoxLayout(velocity_tab_);

    velocity_control_group_ = new QGroupBox("电机2&3 - 同步速度控制 (正弦加减速，按压渐变)(最大速度：1.8 rad/s)", velocity_tab_);
    velocity_control_grid_ = new QGridLayout(velocity_control_group_);

    velocity_control_grid_->addWidget(new QLabel("最大速度绝对值 (rad/s):"), 0, 0);
    vel_max_spin_ = new QDoubleSpinBox();
    vel_max_spin_->setRange(0.0, 50.0);
    vel_max_spin_->setDecimals(3);
    vel_max_spin_->setSingleStep(0.1);
    vel_max_spin_->setValue(1.8);
    velocity_control_grid_->addWidget(vel_max_spin_, 0, 1);

    vel_forward_button_ = new QPushButton("前进 (按住)");
    vel_backward_button_ = new QPushButton("后退 (按住)");
    vel_forward_button_->setCheckable(true);
    vel_backward_button_->setCheckable(true);
    velocity_control_grid_->addWidget(vel_forward_button_, 1, 0);
    velocity_control_grid_->addWidget(vel_backward_button_, 1, 1);

    // 事件连接：按下/释放控制方向
    connect(vel_forward_button_, &QPushButton::pressed, this, &SixMotorPanel::onVelForwardPressed);
    connect(vel_forward_button_, &QPushButton::released, this, &SixMotorPanel::onVelForwardReleased);
    connect(vel_backward_button_, &QPushButton::pressed, this, &SixMotorPanel::onVelBackwardPressed);
    connect(vel_backward_button_, &QPushButton::released, this, &SixMotorPanel::onVelBackwardReleased);

    // 定时器：200Hz 正弦加减速到目标
    if (!vel_ramp_timer_) {
        vel_ramp_timer_ = new QTimer(this);
        vel_ramp_timer_->setTimerType(Qt::PreciseTimer);
        connect(vel_ramp_timer_, &QTimer::timeout, this, &SixMotorPanel::onVelocityRampTick);
        vel_ramp_hz_ = 200; // 控制频率 200Hz
        vel_ramp_timer_->start(std::max(1, 1000 / vel_ramp_hz_));
    }

    // 在按压过程中改变最大速度，实时更新目标
    connect(vel_max_spin_, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, [this](double v){
        Q_UNUSED(v);
        if (vel_cmd_target_dir_ != 0) {
            vel_max_abs_ = std::fabs(vel_max_spin_ ? vel_max_spin_->value() : 0.0);
            vel_profile_start_ = vel_cmd_current_;
            vel_profile_target_ = vel_cmd_target_dir_ * vel_max_abs_;
            vel_profile_t_ = 0.0;
            vel_profile_active_ = true;
        }
    });

    velocity_status_group_ = new QGroupBox("状态", velocity_tab_);
    velocity_status_grid_ = new QGridLayout(velocity_status_group_);
    velocity_status_grid_->addWidget(new QLabel("电机2 当前速度:"), 0, 0);
    velocity_motor2_current_label_ = new QLabel("0.000");
    velocity_status_grid_->addWidget(velocity_motor2_current_label_, 0, 1);
    velocity_status_grid_->addWidget(new QLabel("电机3 当前速度:"), 1, 0);
    velocity_motor3_current_label_ = new QLabel("0.000");
    velocity_status_grid_->addWidget(velocity_motor3_current_label_, 1, 1);

    velocity_layout_->addWidget(velocity_control_group_);
    velocity_layout_->addWidget(velocity_status_group_);

    tab_widget_->addTab(velocity_tab_, "速度(2&3)");
}

void SixMotorPanel::setupTorqueTab()
{
    torque_tab_ = new QWidget(this);
    torque_layout_ = new QVBoxLayout(torque_tab_);

    torque_control_group_ = new QGroupBox("电机4&5 - 力矩控制 (对向同步，正弦3s缓入缓出)", torque_tab_);
    torque_control_grid_ = new QGridLayout(torque_control_group_);

    torque_control_grid_->addWidget(new QLabel("电机4 目标力矩 (Nm，正数):"), 0, 0);
    torque_motor4_spin_ = new QDoubleSpinBox();
    torque_motor4_spin_->setRange(0.0, 10.0);
    torque_motor4_spin_->setDecimals(3);
    torque_motor4_spin_->setSingleStep(0.1);
    torque_motor4_spin_->setToolTip("仅允许非负力矩，电机5自动取反");
    torque_control_grid_->addWidget(torque_motor4_spin_, 0, 1);

    torque_control_grid_->addWidget(new QLabel("电机5 目标力矩 (Nm，始终为电机4取反):"), 1, 0);
    torque_motor5_spin_ = new QDoubleSpinBox();
    torque_motor5_spin_->setRange(-10.0, 10.0);
    torque_motor5_spin_->setDecimals(3);
    torque_motor5_spin_->setSingleStep(0.1);
    torque_control_grid_->addWidget(torque_motor5_spin_, 1, 1);
    torque_motor5_spin_->setEnabled(false);
    torque_motor5_spin_->setToolTip("由电机4目标取反自动计算");

    torque_sync_checkbox_ = new QCheckBox("对向同步已锁定 (4=+T, 5=-T)");
    torque_control_grid_->addWidget(torque_sync_checkbox_, 2, 0, 1, 2);
    torque_sync_checkbox_->setChecked(true);
    torque_sync_checkbox_->setEnabled(false);

    QHBoxLayout* btns = new QHBoxLayout();
    torque_send_button_ = new QPushButton("夹紧");
    torque_stop_button_ = new QPushButton("复位");
    torque_stop_button_->setToolTip("复位到默认：电机4=-1.5, 电机5=+1.5，正弦3s缓入缓出");
    btns->addWidget(torque_send_button_);
    btns->addWidget(torque_stop_button_);
    torque_control_grid_->addLayout(btns, 3, 0, 1, 2);

    connect(torque_send_button_, &QPushButton::clicked, this, &SixMotorPanel::onTorqueSend);
    connect(torque_stop_button_, &QPushButton::clicked, this, &SixMotorPanel::onTorqueStop);
    // 始终保持电机5为电机4取反显示
    connect(torque_motor4_spin_, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, [this](double v){
        torque_motor5_spin_->blockSignals(true);
        torque_motor5_spin_->setValue(-v);
        torque_motor5_spin_->blockSignals(false);
    });
    // 初始化一次电机5显示
    torque_motor5_spin_->setValue(-torque_motor4_spin_->value());

    torque_status_group_ = new QGroupBox("状态", torque_tab_);
    torque_status_grid_ = new QGridLayout(torque_status_group_);
    torque_status_grid_->addWidget(new QLabel("电机4 当前力矩:"), 0, 0);
    torque_motor4_current_label_ = new QLabel("0.000");
    torque_status_grid_->addWidget(torque_motor4_current_label_, 0, 1);
    torque_status_grid_->addWidget(new QLabel("电机5 当前力矩:"), 1, 0);
    torque_motor5_current_label_ = new QLabel("0.000");
    torque_status_grid_->addWidget(torque_motor5_current_label_, 1, 1);

    torque_layout_->addWidget(torque_control_group_);
    torque_layout_->addWidget(torque_status_group_);

    tab_widget_->addTab(torque_tab_, "力矩(4&5)");
}

void SixMotorPanel::setupMonitorTab()
{
    monitor_tab_ = new QWidget(this);
    monitor_layout_ = new QVBoxLayout(monitor_tab_);

    all_motors_status_group_ = new QGroupBox("全量监控", monitor_tab_);
    all_motors_grid_ = new QGridLayout(all_motors_status_group_);

    all_motors_grid_->addWidget(new QLabel("ID"), 0, 0);
    all_motors_grid_->addWidget(new QLabel("名称"), 0, 1);
    all_motors_grid_->addWidget(new QLabel("模式"), 0, 2);
    all_motors_grid_->addWidget(new QLabel("位置"), 0, 3);
    all_motors_grid_->addWidget(new QLabel("速度"), 0, 4);
    all_motors_grid_->addWidget(new QLabel("力矩"), 0, 5);

    int row = 1;
    for (const auto& mc : motor_configs_) {
        all_motors_grid_->addWidget(new QLabel(QString::number(mc.id)), row, 0);
        all_motors_grid_->addWidget(new QLabel(QString::fromStdString(mc.name)), row, 1);
        QLabel* mode = new QLabel(QString::fromStdString(mc.mode_name));
        QLabel* pos = new QLabel("0.000");
        QLabel* vel = new QLabel("0.000");
        QLabel* tor = new QLabel("0.000");
        all_motors_grid_->addWidget(mode, row, 2);
        all_motors_grid_->addWidget(pos, row, 3);
        all_motors_grid_->addWidget(vel, row, 4);
        all_motors_grid_->addWidget(tor, row, 5);
        monitor_mode_labels_[mc.id] = mode;
        monitor_position_labels_[mc.id] = pos;
        monitor_velocity_labels_[mc.id] = vel;
        monitor_torque_labels_[mc.id] = tor;
        row++;
    }

    monitor_layout_->addWidget(all_motors_status_group_);

    tab_widget_->addTab(monitor_tab_, "监控");
}

void SixMotorPanel::setupEmergencyTab()
{
    emergency_tab_ = new QWidget(this);
    emergency_layout_ = new QVBoxLayout(emergency_tab_);

    emergency_control_group_ = new QGroupBox("紧急控制", emergency_tab_);
    QHBoxLayout* btns = new QHBoxLayout(emergency_control_group_);

    emergency_stop_button_ = new QPushButton("快速停机 (全体)");
    fault_reset_button_ = new QPushButton("故障重置 (全体)");
    get_status_button_ = new QPushButton("获取从站状态 (全体)");

    btns->addWidget(emergency_stop_button_);
    btns->addWidget(fault_reset_button_);
    btns->addWidget(get_status_button_);

    connect(emergency_stop_button_, &QPushButton::clicked, this, &SixMotorPanel::onEmergencyStop);
    connect(fault_reset_button_, &QPushButton::clicked, this, &SixMotorPanel::onFaultReset);
    connect(get_status_button_, &QPushButton::clicked, this, &SixMotorPanel::onGetStatus);

    log_group_ = new QGroupBox("系统日志", emergency_tab_);
    QVBoxLayout* log_v = new QVBoxLayout(log_group_);
    log_text_ = new QTextEdit();
    log_text_->setReadOnly(true);
    log_v->addWidget(log_text_);

    emergency_layout_->addWidget(emergency_control_group_);
    emergency_layout_->addWidget(log_group_);

    tab_widget_->addTab(emergency_tab_, "紧急/日志");
}

// ========================= ROS =========================
void SixMotorPanel::setupROS()
{
    operate_mode_pub_ = node_->create_publisher<eu_motor_control::msg::OperateMode>("/motor_control/operate_mode_cmd", 10);
    motor_cmd_pub_ = node_->create_publisher<sensor_msgs::msg::JointState>("/motor_control/motor_cmd", 10);
    emergency_pub_ = node_->create_publisher<eu_motor_control::msg::EmergencyControl>("/motor_control/emg_cmd", 10);

    operate_mode_sub_ = node_->create_subscription<eu_motor_control::msg::OperateMode>(
        "/motor_control/operate_mode_state", 10,
        std::bind(&SixMotorPanel::operateModeStateCallback, this, std::placeholders::_1));

    motor_state_sub_ = node_->create_subscription<sensor_msgs::msg::JointState>(
        "/motor_control/motor_state", 10,
        std::bind(&SixMotorPanel::motorStateCallback, this, std::placeholders::_1));

    emergency_sub_ = node_->create_subscription<eu_motor_control::msg::EmergencyControl>(
        "/motor_control/emg_state", 10,
        std::bind(&SixMotorPanel::emergencyStateCallback, this, std::placeholders::_1));
}

// ========================= 槽函数实现 =========================
void SixMotorPanel::onInitializeAllMotors()
{
    int progressed = 0;
    for (const auto& mc : motor_configs_) {
        setMotorOperateMode(mc.id, true);
        progressed++;
        init_progress_->setValue(progressed);
    }
    overall_status_label_->setText("批量初始化完成");
}

void SixMotorPanel::onPositionSend()
{
    double pos = position_target_spin_->value();
    sendMotorCommand("motor_1", pos, 0.0, 0.0);
    position_target_label_->setText(QString::number(pos, 'f', 3));
}

void SixMotorPanel::onPositionPresetChanged(int)
{
    double v = position_preset_combo_->currentText().toDouble();
    position_target_spin_->setValue(v);
}

// ===== 2&3 同步速度：按压渐变 =====
void SixMotorPanel::onVelForwardPressed()
{
    vel_max_abs_ = std::fabs(vel_max_spin_ ? vel_max_spin_->value() : 0.0);
    vel_cmd_target_dir_ = +1;
    // 启动正弦加速到 +max
    vel_profile_start_ = vel_cmd_current_;
    vel_profile_target_ = +vel_max_abs_;
    vel_profile_t_ = 0.0;
    vel_profile_active_ = true;
}

void SixMotorPanel::onVelForwardReleased()
{
    // 若另一方向仍被按住，则切换到另一方向；否则回零
    vel_cmd_target_dir_ = (vel_backward_button_ && vel_backward_button_->isDown()) ? -1 : 0;
    // 启动到新目标(可能是0或- max)
    vel_profile_start_ = vel_cmd_current_;
    vel_profile_target_ = (vel_cmd_target_dir_ == -1) ? -vel_max_abs_ : 0.0;
    vel_profile_t_ = 0.0;
    vel_profile_active_ = true;
}

void SixMotorPanel::onVelBackwardPressed()
{
    vel_max_abs_ = std::fabs(vel_max_spin_ ? vel_max_spin_->value() : 0.0);
    vel_cmd_target_dir_ = -1;
    vel_profile_start_ = vel_cmd_current_;
    vel_profile_target_ = -vel_max_abs_;
    vel_profile_t_ = 0.0;
    vel_profile_active_ = true;
}

void SixMotorPanel::onVelBackwardReleased()
{
    vel_cmd_target_dir_ = (vel_forward_button_ && vel_forward_button_->isDown()) ? +1 : 0;
    vel_profile_start_ = vel_cmd_current_;
    vel_profile_target_ = (vel_cmd_target_dir_ == +1) ? +vel_max_abs_ : 0.0;
    vel_profile_t_ = 0.0;
    vel_profile_active_ = true;
}

void SixMotorPanel::onVelocityRampTick()
{
    // 正弦/余弦缓入缓出轨迹：
    // v(t) = v_start + (v_target - v_start) * 0.5 * (1 - cos(pi * s)), s = clamp(t/T, 0,1)
    const double dt = 1.0 / static_cast<double>(vel_ramp_hz_ > 0 ? vel_ramp_hz_ : 50);
    if (!vel_profile_active_) {
        // 无轨迹时，维持当前并持续发布，避免看门狗超时
    } else {
        vel_profile_t_ += dt;
        const double T = std::max(vel_ramp_duration_s_, 1e-6);
        double s = vel_profile_t_ / T;
        if (s >= 1.0) {
            s = 1.0;
            vel_profile_active_ = false;
        }
        const double PI = 3.14159265358979323846;
        const double w = 0.5 * (1.0 - std::cos(PI * s));
        vel_cmd_current_ = vel_profile_start_ + (vel_profile_target_ - vel_profile_start_) * w;
    }

    // 力矩：3s正弦缓入缓出到目标；始终保持4/5相反且同步
    // 若处于力矩轨迹，则推进
    if (tor_profile_active_) {
        const double Tt = std::max(tor_ramp_duration_s_, 1e-6);
        double st = tor_profile_t_ / Tt;
        if (st >= 1.0) {
            st = 1.0;
            tor_profile_active_ = false;
        }
        const double PI = 3.14159265358979323846;
        const double wt = 0.5 * (1.0 - std::cos(PI * st));
        tor_cmd_current_ = tor_profile_start_ + (tor_profile_target_ - tor_profile_start_) * wt;
        tor_profile_t_ += dt; // 使用同一dt节拍
    }

    // 将速度与力矩合并发布：motor_2/3 速度，motor_4/5 力矩
    sensor_msgs::msg::JointState msg;
    msg.header.stamp = node_->get_clock()->now();
    msg.name = {"motor_2", "motor_3", "motor_4", "motor_5"};
    msg.position = {0.0, 0.0, 0.0, 0.0};
    msg.velocity = {vel_cmd_current_, vel_cmd_current_, 0.0, 0.0};
    // 力矩相反
    msg.effort = {0.0, 0.0, tor_cmd_current_, -tor_cmd_current_};
    motor_cmd_pub_->publish(msg);
}

void SixMotorPanel::onTorqueSend()
{
    // 读取目标(以电机4为基准，限制为非负)，电机5取相反
    double t = torque_motor4_spin_->value();
    if (t < 0.0) t = 0.0; // 二次保护
    // 启动3s正弦轨迹到目标：起点取当前(可正可负，保证平滑)，目标限制为非负
    tor_profile_start_ = tor_cmd_current_;
    tor_profile_target_ = std::max(0.0, t);
    tor_profile_t_ = 0.0;
    tor_profile_active_ = true;
}

void SixMotorPanel::onTorqueStop()
{
    // 复位：目标设为默认值 电机4=-1.5, 电机5=+1.5（通过相反发布实现）
    tor_profile_start_ = tor_cmd_current_;
    tor_profile_target_ = -1.5;
    tor_profile_t_ = 0.0;
    tor_profile_active_ = true;
}

void SixMotorPanel::onEmergencyStop()
{
    sendEmergencyCommand(3 /*快速停机*/);
}

void SixMotorPanel::onFaultReset()
{
    sendEmergencyCommand(2 /*故障重置*/);
}

void SixMotorPanel::onGetStatus()
{
    sendEmergencyCommand(1 /*获取状态*/);
}

void SixMotorPanel::updateStatus()
{
    updateMotorDisplays();
}

// ========================= 逻辑/工具 =========================
void SixMotorPanel::logMessage(const QString& message)
{
    if (!log_text_) return;
    QString ts = QDateTime::currentDateTime().toString("hh:mm:ss.zzz");
    log_text_->append(QString("[%1] %2").arg(ts, message));
}

void SixMotorPanel::updateMotorDisplays()
{
    auto get = [&](const std::string& name, std::map<std::string,double>& m){
        auto it = m.find(name); return it==m.end()?0.0:it->second; };

    position_current_label_->setText(QString::number(get("motor_1", motor_positions_), 'f', 3));
    velocity_motor2_current_label_->setText(QString::number(get("motor_2", motor_velocities_), 'f', 3));
    velocity_motor3_current_label_->setText(QString::number(get("motor_3", motor_velocities_), 'f', 3));
    torque_motor4_current_label_->setText(QString::number(get("motor_4", motor_torques_), 'f', 3));
    torque_motor5_current_label_->setText(QString::number(get("motor_5", motor_torques_), 'f', 3));

    for (const auto& mc : motor_configs_) {
        monitor_position_labels_[mc.id]->setText(QString::number(get(mc.name, motor_positions_), 'f', 3));
        monitor_velocity_labels_[mc.id]->setText(QString::number(get(mc.name, motor_velocities_), 'f', 3));
        monitor_torque_labels_[mc.id]->setText(QString::number(get(mc.name, motor_torques_), 'f', 3));
    }
}

void SixMotorPanel::setMotorOperateMode(int motor_id, bool enable)
{
    auto it = std::find_if(motor_configs_.begin(), motor_configs_.end(), [&](const MotorConfig& m){return m.id==motor_id;});
    if (it == motor_configs_.end()) return;

    eu_motor_control::msg::OperateMode msg;
    msg.name = it->name;
    msg.operate_mode = it->operate_mode;
    msg.enable_state = enable;
    operate_mode_pub_->publish(msg);
    logMessage(QString("设置模式: %1 -> 模式%2, %3")
        .arg(QString::fromStdString(msg.name))
        .arg(msg.operate_mode)
        .arg(enable?"使能":"禁用"));
}

void SixMotorPanel::sendMotorCommand(const std::string& motor_name, double position, double velocity, double torque)
{
    sensor_msgs::msg::JointState msg;
    msg.header.stamp = node_->get_clock()->now();
    msg.header.frame_id = "base_link";
    msg.name.push_back(motor_name);
    msg.position.push_back(position);
    msg.velocity.push_back(velocity);
    msg.effort.push_back(torque);
    motor_cmd_pub_->publish(msg);

    logMessage(QString("命令: %1 -> Pos:%2, Vel:%3, Tor:%4")
        .arg(QString::fromStdString(motor_name))
        .arg(position, 0, 'f', 3)
        .arg(velocity, 0, 'f', 3)
        .arg(torque, 0, 'f', 3));
}

void SixMotorPanel::sendEmergencyCommand(int command_type, int slave_id)
{
    eu_motor_control::msg::EmergencyControl msg;
    msg.command_type = command_type;
    if (slave_id <= 0) {
        // 全体
        for (const auto& mc : motor_configs_) {
            msg.names.push_back(mc.name);
            msg.slave_ids.push_back(mc.id);
        }
    } else {
        msg.names.push_back("motor_" + std::to_string(slave_id));
        msg.slave_ids.push_back(slave_id);
    }
    msg.success = false;
    emergency_pub_->publish(msg);
}

// ========================= 订阅回调 =========================
void SixMotorPanel::operateModeStateCallback(const eu_motor_control::msg::OperateMode::SharedPtr msg)
{
    auto it = std::find_if(motor_configs_.begin(), motor_configs_.end(), [&](const MotorConfig& m){return m.name==msg->name;});
    if (it == motor_configs_.end()) return;

    it->initialized = true;
    it->enabled = msg->enable_state;
    motor_init_status_labels_[it->id]->setText(QString("模式%1, %2")
        .arg(msg->operate_mode)
        .arg(msg->enable_state?"使能":"禁用"));

    logMessage(QString("状态: %1 模式%2 %3")
        .arg(QString::fromStdString(msg->name))
        .arg(msg->operate_mode)
        .arg(msg->enable_state?"使能":"禁用"));
}

void SixMotorPanel::motorStateCallback(const sensor_msgs::msg::JointState::SharedPtr msg)
{
    for (size_t i=0; i<msg->name.size(); ++i) {
        const auto& n = msg->name[i];
        if (i < msg->position.size()) motor_positions_[n] = msg->position[i];
        if (i < msg->velocity.size()) motor_velocities_[n] = msg->velocity[i];
        if (i < msg->effort.size())   motor_torques_[n]   = msg->effort[i];
    }
}

void SixMotorPanel::emergencyStateCallback(const eu_motor_control::msg::EmergencyControl::SharedPtr msg)
{
    QString type;
    switch (msg->command_type) {
        case 1: type = "获取状态"; break;
        case 2: type = "故障重置"; break;
        case 3: type = "快速停机"; break;
        default: type = "未知"; break;
    }
    logMessage(QString("紧急响应: %1 -> %2").arg(type).arg(msg->success?"成功":"失败"));
    if (msg->command_type == 1 && !msg->slave_states.empty()) {
        for (size_t i=0; i<msg->slave_ids.size() && i<msg->slave_states.size(); ++i) {
            logMessage(QString("从站%1 状态:%2").arg(msg->slave_ids[i]).arg(msg->slave_states[i]));
        }
    }
}

// 导出类
} // namespace eu_motor_control

PLUGINLIB_EXPORT_CLASS(eu_motor_control::SixMotorPanel, rviz_common::Panel)
