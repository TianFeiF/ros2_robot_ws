#ifndef SIX_MOTOR_PANEL_HPP
#define SIX_MOTOR_PANEL_HPP

#include <rclcpp/rclcpp.hpp>
#include <rviz_common/panel.hpp>
#include <rviz_common/display_context.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include "eu_motor_control/msg/operate_mode.hpp"
#include "eu_motor_control/msg/emergency_control.hpp"

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QTabWidget>
#include <QGroupBox>
#include <QLabel>
#include <QPushButton>
#include <QDoubleSpinBox>
#include <QCheckBox>
#include <QComboBox>
#include <QTextEdit>
#include <QProgressBar>
#include <QTimer>
#include <QFrame>
#include <QScrollArea>

#include <memory>
#include <map>
#include <string>
#include <vector>
#include <chrono>

namespace eu_motor_control
{

class SixMotorPanel : public rviz_common::Panel
{
    Q_OBJECT

public:
    explicit SixMotorPanel(QWidget* parent = nullptr);
    virtual ~SixMotorPanel();

    // RViz插件必需方法
    void onInitialize() override;
    void save(rviz_common::Config config) const override;
    void load(const rviz_common::Config& config) override;

private Q_SLOTS:
    // 初始化和模式设置
    void onInitializeAllMotors();
    void onSetSingleMotorMode();
    
    // 位置控制 (Motor 1)
    void onPositionSend();
    void onPositionPresetChanged(int index);
    
    // 速度控制 (Motors 2&3)
    // 2&3 同步速度控制：按压渐变
    void onVelForwardPressed();
    void onVelForwardReleased();
    void onVelBackwardPressed();
    void onVelBackwardReleased();
    void onVelocityRampTick();
    
    // 力矩控制 (Motors 4&5) 
    void onTorqueSend();
    void onTorqueStop();
    void onTorqueSyncToggle();
    
    // 紧急控制
    void onEmergencyStop();
    void onFaultReset();
    void onGetStatus();
    
    // 定时器更新
    void updateStatus();

private:
    // 电机配置
    struct MotorConfig {
        int id;
        std::string name;
        int operate_mode;  // 8=位置, 9=速度, 10=力矩
        std::string mode_name;
        bool initialized;
        bool enabled;
    };
    
    // ROS2组件
    rclcpp::Node::SharedPtr node_;
    rclcpp::Publisher<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_pub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr motor_cmd_pub_;
    rclcpp::Publisher<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_pub_;
    
    rclcpp::Subscription<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr motor_state_sub_;
    rclcpp::Subscription<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_sub_;
    
    // 数据存储
    std::vector<MotorConfig> motor_configs_;
    std::map<std::string, double> motor_positions_;
    std::map<std::string, double> motor_velocities_;
    std::map<std::string, double> motor_torques_;
    std::map<std::string, bool> motor_mode_states_;
    
    // UI组件
    QVBoxLayout* main_layout_;
    QTabWidget* tab_widget_;
    QTimer* status_timer_;
    
    // 初始化标签页
    QWidget* init_tab_;
    QVBoxLayout* init_layout_;
    QGroupBox* init_group_;
    QGridLayout* init_grid_;
    std::map<int, QPushButton*> motor_init_buttons_;
    std::map<int, QLabel*> motor_init_status_labels_;
    QPushButton* init_all_button_;
    QProgressBar* init_progress_;
    QLabel* overall_status_label_;
    
    // 位置控制标签页 (Motor 1)
    QWidget* position_tab_;
    QVBoxLayout* position_layout_;
    QGroupBox* position_control_group_;
    QDoubleSpinBox* position_target_spin_;
    QComboBox* position_preset_combo_;
    QPushButton* position_send_button_;
    QGroupBox* position_status_group_;
    QLabel* position_current_label_;
    QLabel* position_target_label_;
    QLabel* position_mode_status_label_;
    
    // 速度控制标签页 (Motors 2&3)
    QWidget* velocity_tab_;
    QVBoxLayout* velocity_layout_;
    QGroupBox* velocity_control_group_;
    QGridLayout* velocity_control_grid_;
    QDoubleSpinBox* vel_max_spin_;
    QPushButton* vel_forward_button_;
    QPushButton* vel_backward_button_;
    QGroupBox* velocity_status_group_;
    QGridLayout* velocity_status_grid_;
    QLabel* velocity_motor2_current_label_;
    QLabel* velocity_motor3_current_label_;
    QLabel* velocity_motor2_mode_label_;
    QLabel* velocity_motor3_mode_label_;

    // 2&3 按压渐变状态
    QTimer* vel_ramp_timer_ {nullptr};
    double vel_max_abs_ {0.0};
    double vel_cmd_current_ {0.0};
    int vel_cmd_target_dir_ {0}; // -1 后退, 0 停, +1 前进
    double vel_ramp_duration_s_ {1.0};
    int vel_ramp_hz_ {50};
    // 正弦(余弦缓入缓出)加减速轨迹状态
    double vel_profile_start_ {0.0};
    double vel_profile_target_ {0.0};
    double vel_profile_t_ {0.0}; // 从轨迹开始以来的累计时间(s)
    bool vel_profile_active_ {false};
    
    // 力矩控制标签页 (Motors 4&5)
    QWidget* torque_tab_;
    QVBoxLayout* torque_layout_;
    QGroupBox* torque_control_group_;
    QGridLayout* torque_control_grid_;
    QDoubleSpinBox* torque_motor4_spin_;
    QDoubleSpinBox* torque_motor5_spin_;
    QCheckBox* torque_sync_checkbox_;
    QPushButton* torque_send_button_;
    QPushButton* torque_stop_button_;
    QGroupBox* torque_status_group_;
    QGridLayout* torque_status_grid_;
    QLabel* torque_motor4_current_label_;
    QLabel* torque_motor5_current_label_;
    QLabel* torque_motor4_mode_label_;
    QLabel* torque_motor5_mode_label_;
    // 力矩按正弦3s缓入缓出控制状态
    double tor_cmd_current_ {0.0};
    double tor_profile_start_ {0.0};
    double tor_profile_target_ {0.0};
    double tor_profile_t_ {0.0};
    bool tor_profile_active_ {false};
    double tor_ramp_duration_s_ {3.0};
    
    // 监控标签页
    QWidget* monitor_tab_;
    QVBoxLayout* monitor_layout_;
    QGroupBox* all_motors_status_group_;
    QGridLayout* all_motors_grid_;
    std::map<int, QLabel*> monitor_position_labels_;
    std::map<int, QLabel*> monitor_velocity_labels_;
    std::map<int, QLabel*> monitor_torque_labels_;
    std::map<int, QLabel*> monitor_mode_labels_;
    
    // 紧急控制和日志标签页
    QWidget* emergency_tab_;
    QVBoxLayout* emergency_layout_;
    QGroupBox* emergency_control_group_;
    QPushButton* emergency_stop_button_;
    QPushButton* fault_reset_button_;
    QPushButton* get_status_button_;
    QGroupBox* log_group_;
    QTextEdit* log_text_;
    
    // 私有方法
    void setupUI();
    void setupROS();
    void setupMotorConfigs();
    void setupInitTab();
    void setupPositionTab();
    void setupVelocityTab();
    void setupTorqueTab();
    void setupMonitorTab();
    void setupEmergencyTab();
    
    void logMessage(const QString& message);
    void updateMotorDisplays();
    void setMotorOperateMode(int motor_id, bool enable = true);
    void sendMotorCommand(const std::string& motor_name, double position, double velocity, double torque);
    void sendEmergencyCommand(int command_type, int slave_id = -1);
    
    // ROS回调函数
    void operateModeStateCallback(const eu_motor_control::msg::OperateMode::SharedPtr msg);
    void motorStateCallback(const sensor_msgs::msg::JointState::SharedPtr msg);
    void emergencyStateCallback(const eu_motor_control::msg::EmergencyControl::SharedPtr msg);
};

} // namespace eu_motor_control

#endif // SIX_MOTOR_PANEL_HPP
