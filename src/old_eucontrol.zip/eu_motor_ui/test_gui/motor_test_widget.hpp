#ifndef MOTOR_TEST_WIDGET_HPP
#define MOTOR_TEST_WIDGET_HPP

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QLabel>
#include <QPushButton>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QComboBox>
#include <QCheckBox>
#include <QLineEdit>
#include <QTextEdit>
#include <QTimer>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include "eu_motor_control/msg/operate_mode.hpp"
#include "eu_motor_control/msg/emergency_control.hpp"

class MotorTestWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MotorTestWidget(QWidget *parent = nullptr);
    ~MotorTestWidget();

private slots:
    void onSetOperateMode();
    void onSendMotorCommand();
    void onEmergencyCommand();
    void onUpdateStatus();
    
private:
    void setupUI();
    void setupROS();
    void logMessage(const QString& message);
    
    // ROS2 callbacks
    void operateModeStateCallback(const eu_motor_control::msg::OperateMode::SharedPtr msg);
    void motorStateCallback(const sensor_msgs::msg::JointState::SharedPtr msg);
    void emergencyStateCallback(const eu_motor_control::msg::EmergencyControl::SharedPtr msg);
    
    // UI components
    QVBoxLayout* main_layout_;
    QHBoxLayout* top_layout_;
    QVBoxLayout* left_layout_;
    QVBoxLayout* right_layout_;
    
    // 操作模式控制组
    QGroupBox* operate_mode_group_;
    QLineEdit* motor_name_edit_;
    QComboBox* operate_mode_combo_;
    QCheckBox* enable_checkbox_;
    QPushButton* set_mode_button_;
    QLabel* mode_status_label_;
    
    // 电机控制组
    QGroupBox* motor_control_group_;
    QLineEdit* control_motor_name_edit_;
    QDoubleSpinBox* position_spin_;
    QDoubleSpinBox* velocity_spin_;
    QDoubleSpinBox* torque_spin_;
    QPushButton* send_command_button_;
    QLabel* motor_state_label_;
    
    // 紧急控制组
    QGroupBox* emergency_group_;
    QSpinBox* slave_id_spin_;
    QComboBox* emergency_command_combo_;
    QPushButton* emergency_button_;
    QLabel* emergency_status_label_;
    
    // 状态显示
    QTextEdit* log_text_;
    QTimer* status_timer_;
    
    // ROS2 节点和话题
    rclcpp::Node::SharedPtr node_;
    rclcpp::Publisher<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_cmd_pub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr motor_cmd_pub_;
    rclcpp::Publisher<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_cmd_pub_;
    
    rclcpp::Subscription<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_state_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr motor_state_sub_;
    rclcpp::Subscription<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_state_sub_;
    
    // 状态存储
    std::map<std::string, eu_motor_control::msg::OperateMode> motor_modes_;
    std::map<std::string, double> motor_positions_;
    std::map<std::string, double> motor_velocities_;
    std::map<std::string, double> motor_torques_;
};

#endif // MOTOR_TEST_WIDGET_HPP
