#include "motor_test_widget.hpp"
#include <QApplication>
#include <QMessageBox>
#include <QDateTime>
#include <chrono>

MotorTestWidget::MotorTestWidget(QWidget *parent)
    : QWidget(parent)
{
    setupUI();
    setupROS();
    
    // 设置状态更新定时器
    status_timer_ = new QTimer(this);
    connect(status_timer_, &QTimer::timeout, this, &MotorTestWidget::onUpdateStatus);
    status_timer_->start(100); // 10Hz更新
    
    setWindowTitle("电机控制测试界面");
    resize(800, 600);
    
    logMessage("电机控制测试界面启动");
}

MotorTestWidget::~MotorTestWidget()
{
    if (node_) {
        rclcpp::shutdown();
    }
}

void MotorTestWidget::setupUI()
{
    main_layout_ = new QVBoxLayout(this);
    top_layout_ = new QHBoxLayout();
    left_layout_ = new QVBoxLayout();
    right_layout_ = new QVBoxLayout();
    
    // 操作模式控制组
    operate_mode_group_ = new QGroupBox("操作模式控制", this);
    QGridLayout* mode_layout = new QGridLayout(operate_mode_group_);
    
    mode_layout->addWidget(new QLabel("电机名称:"), 0, 0);
    motor_name_edit_ = new QLineEdit("motor_1", this);
    mode_layout->addWidget(motor_name_edit_, 0, 1);
    
    mode_layout->addWidget(new QLabel("操作模式:"), 1, 0);
    operate_mode_combo_ = new QComboBox(this);
    operate_mode_combo_->addItem("同步位置模式 (8)", 8);
    operate_mode_combo_->addItem("同步速度模式 (9)", 9);
    operate_mode_combo_->addItem("同步力矩模式 (10)", 10);
    mode_layout->addWidget(operate_mode_combo_, 1, 1);
    
    enable_checkbox_ = new QCheckBox("使能电机", this);
    enable_checkbox_->setChecked(true);
    mode_layout->addWidget(enable_checkbox_, 2, 0, 1, 2);
    
    set_mode_button_ = new QPushButton("设置操作模式", this);
    connect(set_mode_button_, &QPushButton::clicked, this, &MotorTestWidget::onSetOperateMode);
    mode_layout->addWidget(set_mode_button_, 3, 0, 1, 2);
    
    mode_status_label_ = new QLabel("状态: 未设置", this);
    mode_layout->addWidget(mode_status_label_, 4, 0, 1, 2);
    
    left_layout_->addWidget(operate_mode_group_);
    
    // 电机控制组
    motor_control_group_ = new QGroupBox("电机控制", this);
    QGridLayout* control_layout = new QGridLayout(motor_control_group_);
    
    control_layout->addWidget(new QLabel("电机名称:"), 0, 0);
    control_motor_name_edit_ = new QLineEdit("motor_1", this);
    control_layout->addWidget(control_motor_name_edit_, 0, 1);
    
    control_layout->addWidget(new QLabel("目标位置 (rad):"), 1, 0);
    position_spin_ = new QDoubleSpinBox(this);
    position_spin_->setRange(-10.0, 10.0);
    position_spin_->setDecimals(3);
    position_spin_->setSingleStep(0.1);
    control_layout->addWidget(position_spin_, 1, 1);
    
    control_layout->addWidget(new QLabel("目标速度 (rad/s):"), 2, 0);
    velocity_spin_ = new QDoubleSpinBox(this);
    velocity_spin_->setRange(-10.0, 10.0);
    velocity_spin_->setDecimals(3);
    velocity_spin_->setSingleStep(0.1);
    control_layout->addWidget(velocity_spin_, 2, 1);
    
    control_layout->addWidget(new QLabel("目标力矩 (Nm):"), 3, 0);
    torque_spin_ = new QDoubleSpinBox(this);
    torque_spin_->setRange(-10.0, 10.0);
    torque_spin_->setDecimals(3);
    torque_spin_->setSingleStep(0.1);
    control_layout->addWidget(torque_spin_, 3, 1);
    
    send_command_button_ = new QPushButton("发送控制命令", this);
    connect(send_command_button_, &QPushButton::clicked, this, &MotorTestWidget::onSendMotorCommand);
    control_layout->addWidget(send_command_button_, 4, 0, 1, 2);
    
    motor_state_label_ = new QLabel("状态: 无数据", this);
    control_layout->addWidget(motor_state_label_, 5, 0, 1, 2);
    
    left_layout_->addWidget(motor_control_group_);
    
    // 紧急控制组
    emergency_group_ = new QGroupBox("紧急控制", this);
    QGridLayout* emergency_layout = new QGridLayout(emergency_group_);
    
    emergency_layout->addWidget(new QLabel("从站ID:"), 0, 0);
    slave_id_spin_ = new QSpinBox(this);
    slave_id_spin_->setRange(1, 16);
    slave_id_spin_->setValue(1);
    emergency_layout->addWidget(slave_id_spin_, 0, 1);
    
    emergency_layout->addWidget(new QLabel("紧急命令:"), 1, 0);
    emergency_command_combo_ = new QComboBox(this);
    emergency_command_combo_->addItem("获取状态", 1);
    emergency_command_combo_->addItem("故障重置", 2);
    emergency_command_combo_->addItem("快速停机", 3);
    emergency_layout->addWidget(emergency_command_combo_, 1, 1);
    
    emergency_button_ = new QPushButton("执行紧急命令", this);
    connect(emergency_button_, &QPushButton::clicked, this, &MotorTestWidget::onEmergencyCommand);
    emergency_layout->addWidget(emergency_button_, 2, 0, 1, 2);
    
    emergency_status_label_ = new QLabel("状态: 就绪", this);
    emergency_layout->addWidget(emergency_status_label_, 3, 0, 1, 2);
    
    left_layout_->addWidget(emergency_group_);
    
    // 日志显示
    QGroupBox* log_group = new QGroupBox("系统日志", this);
    QVBoxLayout* log_layout = new QVBoxLayout(log_group);
    log_text_ = new QTextEdit(this);
    log_text_->setMaximumHeight(400);
    log_layout->addWidget(log_text_);
    
    right_layout_->addWidget(log_group);
    
    top_layout_->addLayout(left_layout_);
    top_layout_->addLayout(right_layout_);
    main_layout_->addLayout(top_layout_);
}

void MotorTestWidget::setupROS()
{
    if (!rclcpp::ok()) {
        rclcpp::init(0, nullptr);
    }
    
    node_ = rclcpp::Node::make_shared("motor_test_gui");
    
    // 创建发布者
    operate_mode_cmd_pub_ = node_->create_publisher<eu_motor_control::msg::OperateMode>(
        "/motor_control/operate_mode_cmd", 10);
    
    motor_cmd_pub_ = node_->create_publisher<sensor_msgs::msg::JointState>(
        "/motor_control/motor_cmd", 10);
    
    emergency_cmd_pub_ = node_->create_publisher<eu_motor_control::msg::EmergencyControl>(
        "/motor_control/emg_cmd", 10);
    
    // 创建订阅者
    operate_mode_state_sub_ = node_->create_subscription<eu_motor_control::msg::OperateMode>(
        "/motor_control/operate_mode_state", 10,
        std::bind(&MotorTestWidget::operateModeStateCallback, this, std::placeholders::_1));
    
    motor_state_sub_ = node_->create_subscription<sensor_msgs::msg::JointState>(
        "/motor_control/motor_state", 10,
        std::bind(&MotorTestWidget::motorStateCallback, this, std::placeholders::_1));
    
    emergency_state_sub_ = node_->create_subscription<eu_motor_control::msg::EmergencyControl>(
        "/motor_control/emg_state", 10,
        std::bind(&MotorTestWidget::emergencyStateCallback, this, std::placeholders::_1));
    
    logMessage("ROS2节点初始化完成");
}

void MotorTestWidget::onSetOperateMode()
{
    QString motor_name = motor_name_edit_->text().trimmed();
    if (motor_name.isEmpty()) {
        logMessage("错误: 电机名称不能为空");
        return;
    }
    
    auto msg = eu_motor_control::msg::OperateMode();
    msg.name = motor_name.toStdString();
    msg.operate_mode = operate_mode_combo_->currentData().toInt();
    msg.enable_state = enable_checkbox_->isChecked();
    
    operate_mode_cmd_pub_->publish(msg);
    
    QString mode_text = operate_mode_combo_->currentText();
    QString enable_text = enable_checkbox_->isChecked() ? "使能" : "禁用";
    
    logMessage(QString("发送操作模式命令: %1 -> %2, %3")
               .arg(motor_name).arg(mode_text).arg(enable_text));
    
    mode_status_label_->setText(QString("状态: 已发送命令 - %1, %2").arg(mode_text).arg(enable_text));
}

void MotorTestWidget::onSendMotorCommand()
{
    QString motor_name = control_motor_name_edit_->text().trimmed();
    if (motor_name.isEmpty()) {
        logMessage("错误: 电机名称不能为空");
        return;
    }
    
    auto msg = sensor_msgs::msg::JointState();
    msg.header.stamp = node_->get_clock()->now();
    msg.header.frame_id = "base_link";
    
    msg.name.push_back(motor_name.toStdString());
    msg.position.push_back(position_spin_->value());
    msg.velocity.push_back(velocity_spin_->value());
    msg.effort.push_back(torque_spin_->value());
    
    motor_cmd_pub_->publish(msg);
    
    logMessage(QString("发送电机控制命令: %1 -> Pos:%.3f, Vel:%.3f, Torque:%.3f")
               .arg(motor_name)
               .arg(position_spin_->value())
               .arg(velocity_spin_->value())
               .arg(torque_spin_->value()));
}

void MotorTestWidget::onEmergencyCommand()
{
    int slave_id = slave_id_spin_->value();
    int command_type = emergency_command_combo_->currentData().toInt();
    
    auto msg = eu_motor_control::msg::EmergencyControl();
    msg.names.push_back("motor_" + std::to_string(slave_id));
    msg.slave_ids.push_back(slave_id);
    msg.command_type = command_type;
    msg.success = false; // 将由控制节点设置
    
    emergency_cmd_pub_->publish(msg);
    
    QString command_text = emergency_command_combo_->currentText();
    logMessage(QString("发送紧急命令: 从站%1 -> %2").arg(slave_id).arg(command_text));
    
    emergency_status_label_->setText(QString("状态: 已发送 - %1").arg(command_text));
}

void MotorTestWidget::onUpdateStatus()
{
    // 让ROS处理回调
    if (node_) {
        rclcpp::spin_some(node_);
    }
}

void MotorTestWidget::logMessage(const QString& message)
{
    QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss.zzz");
    log_text_->append(QString("[%1] %2").arg(timestamp).arg(message));
    
    // 保持日志条数在合理范围内
    QTextDocument* doc = log_text_->document();
    if (doc->lineCount() > 1000) {
        QTextCursor cursor(doc);
        cursor.movePosition(QTextCursor::Start);
        cursor.movePosition(QTextCursor::Down, QTextCursor::MoveAnchor, 100);
        cursor.movePosition(QTextCursor::Start, QTextCursor::KeepAnchor);
        cursor.removeSelectedText();
    }
    
    // 自动滚动到底部
    log_text_->moveCursor(QTextCursor::End);
}

void MotorTestWidget::operateModeStateCallback(const eu_motor_control::msg::OperateMode::SharedPtr msg)
{
    motor_modes_[msg->name] = *msg;
    
    QString enable_text = msg->enable_state ? "使能" : "禁用";
    logMessage(QString("收到操作模式状态: %1 -> 模式:%2, %3")
               .arg(QString::fromStdString(msg->name))
               .arg(msg->operate_mode)
               .arg(enable_text));
    
    // 如果是当前选中的电机，更新状态显示
    if (motor_name_edit_->text().toStdString() == msg->name) {
        mode_status_label_->setText(QString("状态: 模式:%1, %2").arg(msg->operate_mode).arg(enable_text));
    }
}

void MotorTestWidget::motorStateCallback(const sensor_msgs::msg::JointState::SharedPtr msg)
{
    for (size_t i = 0; i < msg->name.size(); i++) {
        const std::string& name = msg->name[i];
        
        if (i < msg->position.size()) {
            motor_positions_[name] = msg->position[i];
        }
        if (i < msg->velocity.size()) {
            motor_velocities_[name] = msg->velocity[i];
        }
        if (i < msg->effort.size()) {
            motor_torques_[name] = msg->effort[i];
        }
        
        logMessage(QString("收到电机状态: %1 -> Pos:%.3f, Vel:%.3f, Torque:%.3f")
                   .arg(QString::fromStdString(name))
                   .arg(motor_positions_[name])
                   .arg(motor_velocities_[name])
                   .arg(motor_torques_[name]));
    }
    
    // 如果是当前控制的电机，更新显示
    std::string current_motor = control_motor_name_edit_->text().toStdString();
    if (motor_positions_.find(current_motor) != motor_positions_.end()) {
        motor_state_label_->setText(QString("状态: Pos:%.3f, Vel:%.3f, Torque:%.3f")
                                   .arg(motor_positions_[current_motor])
                                   .arg(motor_velocities_[current_motor])
                                   .arg(motor_torques_[current_motor]));
    }
}

void MotorTestWidget::emergencyStateCallback(const eu_motor_control::msg::EmergencyControl::SharedPtr msg)
{
    QString result = msg->success ? "成功" : "失败";
    
    QString command_text;
    switch (msg->command_type) {
        case 1: command_text = "获取状态"; break;
        case 2: command_text = "故障重置"; break;
        case 3: command_text = "快速停机"; break;
        default: command_text = "未知命令"; break;
    }
    
    logMessage(QString("收到紧急命令响应: %1 -> %2").arg(command_text).arg(result));
    
    if (msg->command_type == 1 && !msg->slave_states.empty()) {
        // 显示状态信息
        for (size_t i = 0; i < msg->slave_ids.size() && i < msg->slave_states.size(); i++) {
            logMessage(QString("从站%1状态: %2").arg(msg->slave_ids[i]).arg(msg->slave_states[i]));
        }
    }
    
    emergency_status_label_->setText(QString("状态: %1 - %2").arg(command_text).arg(result));
}

#include "motor_test_widget.moc"
