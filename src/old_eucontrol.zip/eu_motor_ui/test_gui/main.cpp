#include "motor_test_widget.hpp"
#include <QApplication>
#include <rclcpp/rclcpp.hpp>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    // 初始化ROS2（如果还未初始化）
    if (!rclcpp::ok()) {
        rclcpp::init(argc, argv);
    }
    
    MotorTestWidget widget;
    widget.show();
    
    int result = app.exec();
    
    // 清理ROS2
    if (rclcpp::ok()) {
        rclcpp::shutdown();
    }
    
    return result;
}
