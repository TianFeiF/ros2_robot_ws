#include "motor_control_panel.hpp"
#include <pluginlib/class_list_macros.hpp>
#include <rviz_common/display_context.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>
#include <QApplication>
#include <QMouseEvent>
#include <chrono>
#include <cmath>

namespace eu_motor_control
{

MotorControlPanel::MotorControlPanel(QWidget* parent)
    : rviz_common::Panel(parent)
    , motor_names_()  // 初始为空，将从feedback动态发现
    , move_speed_(0.001)
    , cycle_time_(5.0)
    , angle_range_(3.14)
    , control_frequency_(200)
    , all_initialized_(false)
    , sync_move_direction_(0)
    , motors_discovered_(false)
{
    discovery_start_time_ = std::chrono::steady_clock::now();
    setupUI();
}

MotorControlPanel::~MotorControlPanel()
{
    if (move_timer_) move_timer_->stop();
    if (ui_timer_) ui_timer_->stop();
}

void MotorControlPanel::onInitialize()
{
    // 获取RViz的context并创建节点
    auto context = getDisplayContext()->getRosNodeAbstraction().lock();
    if (context) {
        node_ = context->get_raw_node();
    } else {
        // 如果无法获取context，创建独立节点
        if (!rclcpp::ok()) {
            rclcpp::init(0, nullptr);
        }
        node_ = rclcpp::Node::make_shared("motor_control_panel");
    }
    
    // 创建发布者和订阅者
    cmd_pub_ = node_->create_publisher<sensor_msgs::msg::JointState>("/joint_cmd", 10);
    feedback_sub_ = node_->create_subscription<sensor_msgs::msg::JointState>(
        "/joint_feedback", 10,
        [this](const sensor_msgs::msg::JointState::SharedPtr msg) {
            this->feedbackCallback(msg);
        });
    
    RCLCPP_INFO(node_->get_logger(), "Motor Control Panel initialized - subscribing to /joint_feedback, publishing to /joint_cmd at 200Hz");
    
    // 立即启动定时器，无论电机是否初始化
    // 这确保插件始终以200Hz发布命令
    move_timer_ = new QTimer(this);
    connect(move_timer_, &QTimer::timeout, this, &MotorControlPanel::updateMove);
    move_timer_->start(1000 / control_frequency_);  // 立即开始200Hz发布
    
    ui_timer_ = new QTimer(this);
    connect(ui_timer_, &QTimer::timeout, this, &MotorControlPanel::updateUI);
    ui_timer_->start(50); // 20Hz UI更新
}

void MotorControlPanel::setupUI()
{
    setFixedSize(400, 600);
    main_layout_ = new QVBoxLayout(this);
    
    // 标题
    QLabel* title = new QLabel("电机控制面板", this);
    title->setStyleSheet("font-size: 16px; font-weight: bold; text-align: center;");
    main_layout_->addWidget(title);
    
    // 添加状态标签显示电机发现进度
    QLabel* status = new QLabel("正在搜索电机...", this);
    status->setObjectName("discovery_status");
    status->setStyleSheet("color: orange; text-align: center;");
    main_layout_->addWidget(status);
    
    setupMotorControls();
    setupSyncControls();
    setupParameterControls();
}

void MotorControlPanel::setupMotorControls()
{
    motor_group_ = new QGroupBox("电机控制 (搜索中...)", this);
    motor_grid_ = new QGridLayout(motor_group_);
    
    // 预设表头，但不添加电机行（将动态添加）
    motor_grid_->addWidget(new QLabel("电机"), 0, 0);
    motor_grid_->addWidget(new QLabel("当前角度"), 0, 1);
    motor_grid_->addWidget(new QLabel("目标角度"), 0, 2);
    motor_grid_->addWidget(new QLabel("控制"), 0, 3, 1, 2);
    motor_grid_->addWidget(new QLabel("周期"), 0, 5);
    motor_grid_->addWidget(new QLabel("状态"), 0, 6);
    motor_grid_->addWidget(new QLabel("同步"), 0, 7);
    
    main_layout_->addWidget(motor_group_);
}

void MotorControlPanel::setupSyncControls()
{
    sync_group_ = new QGroupBox("同步控制", this);
    QHBoxLayout* sync_layout = new QHBoxLayout(sync_group_);
    
    sync_left_button_ = new QPushButton("← 同步左移", this);
    sync_right_button_ = new QPushButton("同步右移 →", this);
    sync_status_label_ = new QLabel("同步状态: 停止", this);
    
    // 设置同步按钮按住效果
    sync_left_button_->installEventFilter(this);
    sync_right_button_->installEventFilter(this);
    sync_left_button_->setProperty("sync_direction", -1);
    sync_right_button_->setProperty("sync_direction", 1);
    
    sync_layout->addWidget(sync_left_button_);
    sync_layout->addWidget(sync_right_button_);
    sync_layout->addWidget(sync_status_label_);
    
    main_layout_->addWidget(sync_group_);
}

void MotorControlPanel::setupParameterControls()
{
    QGroupBox* param_group = new QGroupBox("参数设置", this);
    QGridLayout* param_layout = new QGridLayout(param_group);
    
    // 移动速度
    param_layout->addWidget(new QLabel("移动速度:"), 0, 0);
    move_speed_spin_ = new QDoubleSpinBox(this);
    move_speed_spin_->setRange(0.001, 0.1);
    move_speed_spin_->setValue(move_speed_);
    move_speed_spin_->setDecimals(3);
    move_speed_spin_->setSingleStep(0.001);
    connect(move_speed_spin_, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            [this](double value) { move_speed_ = value; });
    param_layout->addWidget(move_speed_spin_, 0, 1);
    
    // 周期时间
    param_layout->addWidget(new QLabel("周期时间:"), 1, 0);
    cycle_time_spin_ = new QDoubleSpinBox(this);
    cycle_time_spin_->setRange(1.0, 20.0);
    cycle_time_spin_->setValue(cycle_time_);
    cycle_time_spin_->setSuffix(" 秒");
    connect(cycle_time_spin_, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            [this](double value) { cycle_time_ = value; });
    param_layout->addWidget(cycle_time_spin_, 1, 1);
    
    // 角度范围
    param_layout->addWidget(new QLabel("角度范围:"), 2, 0);
    angle_range_spin_ = new QDoubleSpinBox(this);
    angle_range_spin_->setRange(0.1, 6.28);
    angle_range_spin_->setValue(angle_range_);
    angle_range_spin_->setSuffix(" 弧度");
    connect(angle_range_spin_, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            [this](double value) { angle_range_ = value; });
    param_layout->addWidget(angle_range_spin_, 2, 1);
    
    // 控制频率
    param_layout->addWidget(new QLabel("控制频率:"), 3, 0);
    frequency_spin_ = new QSpinBox(this);
    frequency_spin_->setRange(10, 1000);
    frequency_spin_->setValue(control_frequency_);
    frequency_spin_->setSuffix(" Hz");
    connect(frequency_spin_, QOverload<int>::of(&QSpinBox::valueChanged),
            [this](int value) { 
                control_frequency_ = value;
                if (move_timer_) {
                    move_timer_->stop();
                    move_timer_->start(1000 / control_frequency_);
                }
            });
    param_layout->addWidget(frequency_spin_, 3, 1);
    
    main_layout_->addWidget(param_group);
}

bool MotorControlPanel::eventFilter(QObject* obj, QEvent* event)
{
    QPushButton* button = qobject_cast<QPushButton*>(obj);
    if (!button) return QWidget::eventFilter(obj, event);
    
    if (event->type() == QEvent::MouseButtonPress) {
        QMouseEvent* mouseEvent = static_cast<QMouseEvent*>(event);
        if (mouseEvent->button() == Qt::LeftButton) {
            // 检查是否是同步按钮
            if (button == sync_left_button_ || button == sync_right_button_) {
                int direction = button->property("sync_direction").toInt();
                sync_move_direction_ = direction;
                return true;
            }
            
            // 检查是否是电机控制按钮
            QString motor_name = button->property("motor_name").toString();
            if (!motor_name.isEmpty()) {
                int direction = button->property("direction").toInt();
                if (direction == -1) {
                    onMotorMoveLeft(motor_name);
                } else if (direction == 1) {
                    onMotorMoveRight(motor_name);
                }
                return true;
            }
        }
    } else if (event->type() == QEvent::MouseButtonRelease) {
        QMouseEvent* mouseEvent = static_cast<QMouseEvent*>(event);
        if (mouseEvent->button() == Qt::LeftButton) {
            // 同步按钮释放
            if (button == sync_left_button_ || button == sync_right_button_) {
                sync_move_direction_ = 0;
                return true;
            }
            
            // 电机按钮释放
            QString motor_name = button->property("motor_name").toString();
            if (!motor_name.isEmpty()) {
                onMotorStop(motor_name);
                return true;
            }
        }
    }
    
    return QWidget::eventFilter(obj, event);
}

void MotorControlPanel::feedbackCallback(const sensor_msgs::msg::JointState::SharedPtr msg)
{
    bool ui_needs_update = false;
    
    // 检查是否发现新电机
    for (size_t i = 0; i < msg->name.size() && i < msg->position.size(); ++i) {
        const auto& name = msg->name[i];
        
        // 如果是新电机，添加到列表
        if (std::find(motor_names_.begin(), motor_names_.end(), name) == motor_names_.end()) {
            motor_names_.push_back(name);
            
            // 初始化新电机的状态
            motor_positions_[name] = 0.0;
            target_positions_[name] = 0.0;
            cyclic_mode_[name] = false;
            move_direction_[name] = 0;
            initial_positions_[name] = 0.0;
            positions_initialized_[name] = false;
            
            ui_needs_update = true;
            RCLCPP_INFO(node_->get_logger(), "Discovered new motor: %s", name.c_str());
        }
        
        // 更新电机位置
        motor_positions_[name] = msg->position[i];
        
        // 如果是第一次接收到该电机的反馈，初始化目标位置
        if (!positions_initialized_[name]) {
            initial_positions_[name] = msg->position[i];
            target_positions_[name] = msg->position[i];
            positions_initialized_[name] = true;
            
            RCLCPP_INFO(node_->get_logger(), "Initialized %s at position: %.3f", 
                       name.c_str(), msg->position[i]);
        }
    }
    
    // 如果发现了新电机且还未完成UI构建，重建UI
    if (ui_needs_update && !motors_discovered_) {
        rebuildMotorUI();
        motors_discovered_ = true;
    }
    
    // 检查所有电机是否都已初始化
    all_initialized_ = true;
    for (const auto& name : motor_names_) {
        if (!positions_initialized_[name]) {
            all_initialized_ = false;
            break;
        }
    }
    
    if (all_initialized_ && !motor_names_.empty()) {
        // 更新发现状态显示
        updateMotorDiscovery();
        RCLCPP_INFO_ONCE(node_->get_logger(), "All %zu motors initialized, ready for control", motor_names_.size());
    }
}

void MotorControlPanel::onMotorMoveLeft(const QString& motor_name)
{
    if (!all_initialized_) {
        RCLCPP_WARN(node_->get_logger(), "Motors not initialized yet, cannot move %s", 
                   motor_name.toStdString().c_str());
        return;
    }
    move_direction_[motor_name.toStdString()] = -1;
    // 停止该电机的周期运动
    std::string name = motor_name.toStdString();
    if (cyclic_mode_[name]) {
        cyclic_mode_[name] = false;
        cycle_buttons_[name]->setText("周期:关");
    }
}

void MotorControlPanel::onMotorMoveRight(const QString& motor_name)
{
    if (!all_initialized_) {
        RCLCPP_WARN(node_->get_logger(), "Motors not initialized yet, cannot move %s", 
                   motor_name.toStdString().c_str());
        return;
    }
    move_direction_[motor_name.toStdString()] = 1;
    // 停止该电机的周期运动
    std::string name = motor_name.toStdString();
    if (cyclic_mode_[name]) {
        cyclic_mode_[name] = false;
        cycle_buttons_[name]->setText("周期:关");
    }
}

void MotorControlPanel::onMotorStop(const QString& motor_name)
{
    move_direction_[motor_name.toStdString()] = 0;
}

void MotorControlPanel::onToggleCycle(const QString& motor_name)
{
    if (!all_initialized_) {
        RCLCPP_WARN(node_->get_logger(), "Motors not initialized yet, cannot toggle cycle for %s", 
                   motor_name.toStdString().c_str());
        return;
    }
    
    std::string name = motor_name.toStdString();
    cyclic_mode_[name] = !cyclic_mode_[name];
    
    if (cyclic_mode_[name]) {
        // 开始周期运动
        cycle_start_time_[name] = std::chrono::steady_clock::now();
        initial_positions_[name] = motor_positions_[name];
        cycle_buttons_[name]->setText("周期:开");
        // 停止手动移动
        move_direction_[name] = 0;
        RCLCPP_INFO(node_->get_logger(), "Started cyclic motion for %s from position %.3f", 
                   name.c_str(), motor_positions_[name]);
    } else {
        cycle_buttons_[name]->setText("周期:关");
        RCLCPP_INFO(node_->get_logger(), "Stopped cyclic motion for %s", name.c_str());
    }
}

void MotorControlPanel::updateMove()
{
    bool control_updated = false;
    
    // 处理单电机移动
    for (const auto& name : motor_names_) {
        if (move_direction_[name] != 0) {
            target_positions_[name] += move_direction_[name] * move_speed_;
            control_updated = true;
        }
        
        // 处理周期运动
        if (cyclic_mode_[name]) {
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                now - cycle_start_time_[name]).count() / 1000.0;
            target_positions_[name] = calculateCycleAngle(elapsed, name);
            control_updated = true;
        }
    }
    
    // 处理同步移动
    if (sync_move_direction_ != 0) {
        auto selected_motors = getSelectedMotors();
        for (const auto& name : selected_motors) {
            target_positions_[name] += sync_move_direction_ * move_speed_;
            control_updated = true;
        }
    }
    
    // 无论是否有控制更新，都持续发送目标位置（200Hz）
    // 这确保电机始终保持目标位置，即使没有主动控制
    sendMotorCommand();
    
    // 可选：仅在有控制更新时记录日志（避免日志过多）
    if (control_updated) {
        RCLCPP_DEBUG(node_->get_logger(), "Motor targets updated and published");
    }
}

void MotorControlPanel::updateUI()
{
    for (const auto& name : motor_names_) {
        // 更新位置显示
        position_labels_[name]->setText(
            QString::number(motor_positions_[name], 'f', 2));
        
        // 更新目标角度输入框
        target_entries_[name]->setText(
            QString::number(target_positions_[name], 'f', 2));
        
        // 更新状态标签
        if (cyclic_mode_[name]) {
            status_labels_[name]->setText("周期中");
        } else if (move_direction_[name] != 0) {
            status_labels_[name]->setText("手动中");
        } else {
            status_labels_[name]->setText("静止");
        }
    }
    
    // 更新同步状态
    if (sync_move_direction_ != 0) {
        sync_status_label_->setText("同步状态: 移动中");
    } else {
        auto selected = getSelectedMotors();
        sync_status_label_->setText(
            QString("同步状态: 已选择%1个电机").arg(selected.size()));
    }
}

void MotorControlPanel::sendMotorCommand()
{
    // 检查基本条件
    if (!node_ || !cmd_pub_) {
        return;
    }
    
    // 创建JointState消息
    auto msg = std::make_shared<sensor_msgs::msg::JointState>();
    msg->header.stamp = node_->now();
    msg->header.frame_id = "";
    
    // 如果还没有发现电机，也要发送消息以保持200Hz频率
    if (motor_names_.empty()) {
        // 发送一个默认电机名称的0位置，确保消息不为空
        msg->name.push_back("motor_default");
        msg->position.push_back(0.0);
    } else {
        // 添加所有已知电机的目标位置
        for (const auto& name : motor_names_) {
            msg->name.push_back(name);
            // 如果电机已初始化，发送目标位置；否则发送当前位置或0
            if (positions_initialized_[name]) {
                msg->position.push_back(target_positions_[name]);
            } else {
                msg->position.push_back(motor_positions_.find(name) != motor_positions_.end() ? 
                                      motor_positions_[name] : 0.0);
            }
        }
    }
    
    // 始终发布消息，保持200Hz通信频率
    cmd_pub_->publish(*msg);
    
    // 定期日志（每5秒打印一次状态）
    static auto last_log_time = std::chrono::steady_clock::now();
    auto now = std::chrono::steady_clock::now();
    if (std::chrono::duration_cast<std::chrono::seconds>(now - last_log_time).count() >= 5) {
        if (all_initialized_) {
            RCLCPP_INFO(node_->get_logger(), "Publishing motor commands at 200Hz - %zu motors active", 
                       motor_names_.size());
        } else {
            RCLCPP_INFO(node_->get_logger(), "Publishing motor commands at 200Hz - waiting for motor initialization");
        }
        last_log_time = now;
    }
}

double MotorControlPanel::calculateCycleAngle(double elapsed_time, const std::string& motor_name)
{
    double init = initial_positions_[motor_name];
    double cycle_pos = fmod(elapsed_time, cycle_time_) / cycle_time_;
    
    if (cycle_pos <= 0.5) {
        double progress = cycle_pos * 2.0;
        return init + progress * angle_range_;
    } else {
        double progress = (cycle_pos - 0.5) * 2.0;
        return init + angle_range_ - progress * angle_range_;
    }
}

std::vector<std::string> MotorControlPanel::getSelectedMotors()
{
    std::vector<std::string> selected;
    for (const auto& name : motor_names_) {
        if (sync_checkboxes_[name]->isChecked()) {
            selected.push_back(name);
        }
    }
    return selected;
}

void MotorControlPanel::createMotorUI(const std::string& name, int row)
{
    // 电机名称
    motor_grid_->addWidget(new QLabel(QString::fromStdString(name)), row, 0);
    
    // 当前角度显示
    position_labels_[name] = new QLabel("0.00", this);
    motor_grid_->addWidget(position_labels_[name], row, 1);
    
    // 目标角度输入
    target_entries_[name] = new QLineEdit("0.0", this);
    target_entries_[name]->setMaximumWidth(60);
    motor_grid_->addWidget(target_entries_[name], row, 2);
    
    // 左右控制按钮
    left_buttons_[name] = new QPushButton("←", this);
    right_buttons_[name] = new QPushButton("→", this);
    left_buttons_[name]->setMaximumWidth(30);
    right_buttons_[name]->setMaximumWidth(30);
    
    // 设置按钮按住效果
    left_buttons_[name]->installEventFilter(this);
    right_buttons_[name]->installEventFilter(this);
    left_buttons_[name]->setProperty("motor_name", QString::fromStdString(name));
    right_buttons_[name]->setProperty("motor_name", QString::fromStdString(name));
    left_buttons_[name]->setProperty("direction", -1);
    right_buttons_[name]->setProperty("direction", 1);
    
    motor_grid_->addWidget(left_buttons_[name], row, 3);
    motor_grid_->addWidget(right_buttons_[name], row, 4);
    
    // 周期运动按钮
    cycle_buttons_[name] = new QPushButton("周期:关", this);
    connect(cycle_buttons_[name], &QPushButton::clicked,
            [this, name]() { this->onToggleCycle(QString::fromStdString(name)); });
    motor_grid_->addWidget(cycle_buttons_[name], row, 5);
    
    // 状态标签
    status_labels_[name] = new QLabel("未初始化", this);
    motor_grid_->addWidget(status_labels_[name], row, 6);
    
    // 同步选择框
    sync_checkboxes_[name] = new QCheckBox(this);
    motor_grid_->addWidget(sync_checkboxes_[name], row, 7);
}

void MotorControlPanel::rebuildMotorUI()
{
    // 更新组框标题
    motor_group_->setTitle(QString("电机控制 (发现 %1 个电机)").arg(motor_names_.size()));
    
    // 为每个发现的电机创建UI
    for (size_t i = 0; i < motor_names_.size(); ++i) {
        const auto& name = motor_names_[i];
        int row = i + 1;  // 跳过表头行
        
        // 如果该电机的UI组件还不存在，创建它们
        if (position_labels_.find(name) == position_labels_.end()) {
            createMotorUI(name, row);
        }
    }
    
    // 强制布局更新
    motor_grid_->update();
    this->update();
}

void MotorControlPanel::updateMotorDiscovery()
{
    // 更新状态标签
    QLabel* status = findChild<QLabel*>("discovery_status");
    if (status) {
        if (motor_names_.empty()) {
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - discovery_start_time_).count();
            
            if (elapsed < DISCOVERY_TIMEOUT_SECONDS) {
                status->setText(QString("正在搜索电机... (%1/%2秒)").arg(elapsed).arg(static_cast<int>(DISCOVERY_TIMEOUT_SECONDS)));
                status->setStyleSheet("color: orange;");
            } else {
                status->setText("未发现电机 - 请检查 /joint_feedback 话题");
                status->setStyleSheet("color: red;");
            }
        } else if (all_initialized_) {
            status->setText(QString("已发现并初始化 %1 个电机").arg(motor_names_.size()));
            status->setStyleSheet("color: green;");
        } else {
            status->setText(QString("已发现 %1 个电机，正在初始化...").arg(motor_names_.size()));
            status->setStyleSheet("color: blue;");
        }
    }
}

void MotorControlPanel::save(rviz_common::Config config) const
{
    rviz_common::Panel::save(config);
    config.mapSetValue("move_speed", move_speed_);
    config.mapSetValue("cycle_time", cycle_time_);
    config.mapSetValue("angle_range", angle_range_);
    config.mapSetValue("control_frequency", control_frequency_);
}

void MotorControlPanel::load(const rviz_common::Config& config)
{
    rviz_common::Panel::load(config);
    
    float temp_move_speed, temp_cycle_time, temp_angle_range;
    int temp_frequency;
    
    if (config.mapGetFloat("move_speed", &temp_move_speed))
        move_speed_ = temp_move_speed;
    if (config.mapGetFloat("cycle_time", &temp_cycle_time))
        cycle_time_ = temp_cycle_time;
    if (config.mapGetFloat("angle_range", &temp_angle_range))
        angle_range_ = temp_angle_range;
    if (config.mapGetInt("control_frequency", &temp_frequency))
        control_frequency_ = temp_frequency;
        
    // 更新UI组件
    if (move_speed_spin_) move_speed_spin_->setValue(move_speed_);
    if (cycle_time_spin_) cycle_time_spin_->setValue(cycle_time_);
    if (angle_range_spin_) angle_range_spin_->setValue(angle_range_);
    if (frequency_spin_) frequency_spin_->setValue(control_frequency_);
}

} // namespace eu_motor_control

PLUGINLIB_EXPORT_CLASS(eu_motor_control::MotorControlPanel, rviz_common::Panel)
