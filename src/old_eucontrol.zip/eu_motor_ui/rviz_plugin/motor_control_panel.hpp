#ifndef MOTOR_CONTROL_PANEL_H
#define MOTOR_CONTROL_PANEL_H

#include <rclcpp/rclcpp.hpp>
#include <rviz_common/panel.hpp>
#include <rviz_common/display_context.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include "eu_motor_control/msg/operate_mode.hpp"
#include "eu_motor_control/msg/emergency_control.hpp"
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QCheckBox>
#include <QGroupBox>
#include <QTimer>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QComboBox>
#include <QTextEdit>
#include <QProgressBar>
#include <QTabWidget>
#include <memory>
#include <map>
#include <string>

namespace eu_motor_control
{

class MotorControlPanel : public rviz_common::Panel
{
    Q_OBJECT

public:
    explicit MotorControlPanel(QWidget* parent = nullptr);
    virtual ~MotorControlPanel();

    // RViz 插件必需的方法
    void onInitialize() override;
    void save(rviz_common::Config config) const override;
    void load(const rviz_common::Config& config) override;

private Q_SLOTS:
    // 初始化和模式设置槽函数
    void onInitializeMotors();
    void onSetAllModes();
    
    // 位置控制槽函数 (Motor 1)
    void onSendPositionCommand();
    void onPositionPresetSelected(int preset);
    
    // 速度控制槽函数 (Motors 2,3)
    void onSendVelocityCommand();
    void onVelocityStopMotors();
    
    // 力矩控制槽函数 (Motors 4,5)
    void onSendTorqueCommand();
    void onTorqueStopMotors();
    
    // 紧急控制槽函数
    void onEmergencyStop();
    void onFaultReset();
    void onGetMotorStatus();
    
    // 定时器槽函数
    void updateStatus();

private:
    // ROS2 相关
    rclcpp::Node::SharedPtr node_;
    rclcpp::Publisher<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_cmd_pub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr motor_cmd_pub_;
    rclcpp::Publisher<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_cmd_pub_;
    
    rclcpp::Subscription<eu_motor_control::msg::OperateMode>::SharedPtr operate_mode_state_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr motor_state_sub_;
    rclcpp::Subscription<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_state_sub_;
    
    // 电机配置
    struct MotorConfig {
        int id;
        std::string name;
        int operate_mode;  // 8=位置, 9=速度, 10=力矩
        bool initialized;
        bool enabled;
    };
    
    std::vector<MotorConfig> motor_configs_;
    
    // 状态存储
    std::map<std::string, double> motor_positions_;
    std::map<std::string, double> motor_velocities_;
    std::map<std::string, double> motor_torques_;
    std::map<std::string, bool> motor_initialized_states_;
    
    // UI 组件
    QVBoxLayout* main_layout_;
    QTimer* status_timer_;
    QTabWidget* tab_widget_;
    
    // 初始化页面
    QWidget* init_tab_;
    QVBoxLayout* init_layout_;
    QGroupBox* init_group_;
    QPushButton* init_motors_button_;
    QPushButton* set_all_modes_button_;
    QLabel* init_status_label_;
    QProgressBar* init_progress_;
    
    // 位置控制页面 (Motor 1)
    QWidget* position_tab_;
    QVBoxLayout* position_layout_;
    QGroupBox* position_group_;
    QDoubleSpinBox* position_target_spin_;
    QComboBox* position_preset_combo_;
    QPushButton* position_send_button_;
    QLabel* position_current_label_;
    QLabel* position_status_label_;
    
    // 速度控制页面 (Motors 2,3)
    QWidget* velocity_tab_;
    QVBoxLayout* velocity_layout_;
    QGroupBox* velocity_group_;
    QDoubleSpinBox* velocity_motor2_spin_;
    QDoubleSpinBox* velocity_motor3_spin_;
    QCheckBox* velocity_sync_checkbox_;
    QPushButton* velocity_send_button_;
    QPushButton* velocity_stop_button_;
    QLabel* velocity_motor2_label_;
    QLabel* velocity_motor3_label_;
    QLabel* velocity_status_label_;
    
    // 力矩控制页面 (Motors 4,5)
    QWidget* torque_tab_;
    QVBoxLayout* torque_layout_;
    QGroupBox* torque_group_;
    QDoubleSpinBox* torque_motor4_spin_;
    QDoubleSpinBox* torque_motor5_spin_;
    QCheckBox* torque_sync_checkbox_;
    QPushButton* torque_send_button_;
    QPushButton* torque_stop_button_;
    QLabel* torque_motor4_label_;
    QLabel* torque_motor5_label_;
    QLabel* torque_status_label_;
    
    // 监控页面
    QWidget* monitor_tab_;
    QVBoxLayout* monitor_layout_;
    QGroupBox* status_group_;
    QGridLayout* status_grid_;
    std::map<std::string, QLabel*> status_position_labels_;
    std::map<std::string, QLabel*> status_velocity_labels_;
    std::map<std::string, QLabel*> status_torque_labels_;
    std::map<std::string, QLabel*> status_mode_labels_;
    
    // 紧急控制页面
    QWidget* emergency_tab_;
    QVBoxLayout* emergency_layout_;
    QGroupBox* emergency_group_;
    QPushButton* emergency_stop_button_;
    QPushButton* fault_reset_button_;
    QPushButton* get_status_button_;
    QTextEdit* log_text_;
    
    // 私有方法
    void setupUI();
    void setupROS();
    void setupInitTab();
    void setupPositionTab();
    void setupVelocityTab();
    void setupTorqueTab();
    void setupMonitorTab();
    void setupEmergencyTab();
    void logMessage(const QString& message);
    void updateMotorStatusDisplay();
    void updateInitializationProgress();
    
    // ROS2 回调函数
    void operateModeStateCallback(const eu_motor_control::msg::OperateMode::SharedPtr msg);
    void motorStateCallback(const sensor_msgs::msg::JointState::SharedPtr msg);
    void emergencyStateCallback(const eu_motor_control::msg::EmergencyControl::SharedPtr msg);
};

} // namespace eu_motor_control

#endif // MOTOR_CONTROL_PANEL_H
