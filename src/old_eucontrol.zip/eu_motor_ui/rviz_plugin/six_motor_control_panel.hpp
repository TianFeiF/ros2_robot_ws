#ifndef SIX_MOTOR_CONTROL_PANEL_HPP
#define SIX_MOTOR_CONTROL_PANEL_HPP

#include <rclcpp/rclcpp.hpp>
#include <rviz_common/panel.hpp>
#include <rviz_common/display_context.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include "eu_motor_control/msg/operate_mode.hpp"
#include "eu_motor_control/msg/emergency_control.hpp"

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QCheckBox>
#include <QGroupBox>
#include <QTimer>
#include <QDoubleSpinBox>
#include <QComboBox>
#include <QTextEdit>
#include <QProgressBar>
#include <QTabWidget>
#include <QFrame>
#include <QSplitter>

#include <memory>
#include <map>
#include <string>
#include <vector>

namespace eu_motor_control
{

class SixMotorControlPanel : public rviz_common::Panel
{
    Q_OBJECT

public:
    explicit SixMotorControlPanel(QWidget* parent = nullptr);
    virtual ~SixMotorControlPanel();

    // RViz 插件必需的方法
    void onInitialize() override;
    void save(rviz_common::Config config) const override;
    void load(const rviz_common::Config& config) override;

private Q_SLOTS:
    // 初始化控制
    void onInitializeAllMotors();
    
    // 位置控制 (Motor 1)
    void onPositionCommand();
    void onPositionPreset();
    
    // 速度控制 (Motors 2,3)
    void onVelocityCommand();
    void onVelocityStop();
    void onVelocitySync(bool enabled);
    
    // 力矩控制 (Motors 4,5)
    void onTorqueCommand();
    void onTorqueStop();
    void onTorqueSync(bool enabled);
    
    // 紧急控制
    void onEmergencyStop();
    void onFaultReset();
    void onStatusQuery();
    
    // 定时器更新
    void updateStatus();

private:
    // 电机配置结构
    struct MotorInfo {
        int id;
        std::string name;
        int control_mode;  // 8=位置, 9=速度, 10=力矩
        bool initialized;
        bool enabled;
        double current_position;
        double current_velocity;
        double current_torque;
    };

    // ROS2 相关
    rclcpp::Node::SharedPtr node_;
    rclcpp::Publisher<eu_motor_control::msg::OperateMode>::SharedPtr mode_cmd_pub_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_cmd_pub_;
    rclcpp::Publisher<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_cmd_pub_;
    
    rclcpp::Subscription<eu_motor_control::msg::OperateMode>::SharedPtr mode_state_sub_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_state_sub_;
    rclcpp::Subscription<eu_motor_control::msg::EmergencyControl>::SharedPtr emergency_state_sub_;
    
    // 电机信息
    std::vector<MotorInfo> motors_;
    
    // UI组件
    QVBoxLayout* main_layout_;
    QTimer* status_timer_;
    
    // 初始化区域
    QGroupBox* init_group_;
    QPushButton* init_all_button_;
    QProgressBar* init_progress_;
    QLabel* init_status_label_;
    
    // 控制区域 - 使用分割器
    QSplitter* control_splitter_;
    
    // 位置控制 (Motor 1)
    QGroupBox* position_group_;
    QDoubleSpinBox* position_target_spin_;
    QComboBox* position_preset_combo_;
    QPushButton* position_send_button_;
    QLabel* position_current_label_;
    QLabel* position_status_label_;
    
    // 速度控制 (Motors 2,3)
    QGroupBox* velocity_group_;
    QDoubleSpinBox* vel_motor2_spin_;
    QDoubleSpinBox* vel_motor3_spin_;
    QCheckBox* vel_sync_checkbox_;
    QPushButton* vel_send_button_;
    QPushButton* vel_stop_button_;
    QLabel* vel_motor2_current_label_;
    QLabel* vel_motor3_current_label_;
    QLabel* vel_status_label_;
    
    // 力矩控制 (Motors 4,5)
    QGroupBox* torque_group_;
    QDoubleSpinBox* torque_motor4_spin_;
    QDoubleSpinBox* torque_motor5_spin_;
    QCheckBox* torque_sync_checkbox_;
    QPushButton* torque_send_button_;
    QPushButton* torque_stop_button_;
    QLabel* torque_motor4_current_label_;
    QLabel* torque_motor5_current_label_;
    QLabel* torque_status_label_;
    
    // 状态监控区域
    QGroupBox* monitor_group_;
    QGridLayout* monitor_grid_;
    std::map<int, QLabel*> motor_pos_labels_;
    std::map<int, QLabel*> motor_vel_labels_;
    std::map<int, QLabel*> motor_torque_labels_;
    std::map<int, QLabel*> motor_mode_labels_;
    
    // 紧急控制和日志
    QGroupBox* emergency_group_;
    QPushButton* emergency_stop_button_;
    QPushButton* fault_reset_button_;
    QPushButton* status_query_button_;
    QTextEdit* log_display_;
    
    // 私有方法
    void setupUI();
    void setupROS();
    void setupMotorConfigs();
    void setupInitGroup();
    void setupPositionGroup();
    void setupVelocityGroup();
    void setupTorqueGroup();
    void setupMonitorGroup();
    void setupEmergencyGroup();
    
    void logMessage(const QString& message);
    void updateMotorDisplays();
    void sendOperateMode(int motor_id, bool enable = true);
    
    // ROS回调函数
    void onOperateModeState(const eu_motor_control::msg::OperateMode::SharedPtr msg);
    void onJointState(const sensor_msgs::msg::JointState::SharedPtr msg);
    void onEmergencyState(const eu_motor_control::msg::EmergencyControl::SharedPtr msg);
};

} // namespace eu_motor_control

#endif // SIX_MOTOR_CONTROL_PANEL_HPP
